<?php
/**
 * Webhook Handler for Slack/Discord notifications
 *
 * Sends 404 Slimmer events (e.g. blocked request spikes) to configurable webhook URLs.
 * Compatible with Slack Incoming Webhooks and Discord Webhooks.
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Class OVCD_Webhook_Handler
 */
class OVCD_Webhook_Handler {

	/**
	 * Option key for webhook URL
	 */
	const OPTION_WEBHOOK_URL = 'ovcd_404_slimmer_webhook_url';

	/**
	 * Option key for webhook enabled
	 */
	const OPTION_WEBHOOK_ENABLED = 'ovcd_404_slimmer_webhook_enabled';

	/**
	 * Send a payload to the configured webhook (Slack or Discord).
	 *
	 * @param string $title   Short title (e.g. "404 Slimmer – Blocked request").
	 * @param string $body    Message body or description.
	 * @param array  $extra   Optional key-value pairs to append as fields.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public static function send($title, $body = '', array $extra = array()) {
		$url = get_option(self::OPTION_WEBHOOK_URL, '');
		if ($url === '' || ! get_option(self::OPTION_WEBHOOK_ENABLED, false)) {
			return false;
		}

		$url = esc_url_raw($url);
		if ($url === '') {
			return new WP_Error('ovcd_webhook_invalid_url', __('Invalid webhook URL.', '404-slimmer'));
		}

		// Detect Slack vs Discord: Slack uses JSON with "text" or "blocks"; Discord uses "content" or "embeds"
		$is_slack = strpos($url, 'hooks.slack.com') !== false;
		$payload  = self::build_payload($title, $body, $extra, $is_slack);

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 10,
				'headers' => array('Content-Type' => 'application/json'),
				'body'    => wp_json_encode($payload),
			)
		);

		if (is_wp_error($response)) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);
		if ($code < 200 || $code >= 300) {
			return new WP_Error(
				'ovcd_webhook_http_error',
				sprintf(__('Webhook returned HTTP %d.', '404-slimmer'), $code)
			);
		}

		return true;
	}

	/**
	 * Build payload for Slack or Discord.
	 *
	 * @param string $title   Title.
	 * @param string $body    Body text.
	 * @param array  $extra   Extra fields.
	 * @param bool   $slack   True for Slack format.
	 * @return array
	 */
	private static function build_payload($title, $body, array $extra, $slack) {
		if ($slack) {
			$text = $title;
			if ($body !== '') {
				$text .= "\n" . $body;
			}
			foreach ($extra as $key => $value) {
				$text .= "\n" . (is_string($key) ? $key . ': ' : '') . $value;
			}
			return array('text' => $text);
		}

		// Discord embed
		$embed = array(
			'title'       => $title,
			'description' => $body !== '' ? $body : null,
			'color'       => 3447003, // Blue
			'footer'      => array('text' => '404 Slimmer • ' . get_bloginfo('name')),
		);
		if (! empty($extra)) {
			$embed['fields'] = array();
			foreach ($extra as $key => $value) {
				$embed['fields'][] = array(
					'name'   => is_string($key) ? $key : 'Info',
					'value'  => (string) $value,
					'inline' => true,
				);
			}
		}
		return array('embeds' => array($embed));
	}
}
