 <?php
/**
 * Freemium helpers for 404 Slimmer
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Check if PRO features are unlocked (valid license).
 * Multisite: network-level license (valid in network admin) applies to all sites; else site-level.
 * สำหรับทดสอบ: ใส่ใน wp-config.php ได้ define('OVCD_404_FORCE_PRO', true);
 *
 * @return bool
 */
function ovcd_404_slimmer_is_pro() {
	if (defined('OVCD_404_FORCE_PRO') && OVCD_404_FORCE_PRO) {
		return true;
	}
	$status = '';
	$data   = array();
	if (is_multisite()) {
		$status = get_network_option(null, 'ovcd_404_slimmer_license_status', '');
		$data   = get_network_option(null, 'ovcd_404_slimmer_license_data', array());
		if ($status !== 'valid') {
			$status = get_option('ovcd_404_slimmer_license_status', '');
			$data   = get_option('ovcd_404_slimmer_license_data', array());
		}
	} else {
		$status = get_option('ovcd_404_slimmer_license_status', '');
		$data   = get_option('ovcd_404_slimmer_license_data', array());
	}
	if ($status !== 'valid') {
		return false;
	}
	if (! is_array($data)) {
		return true;
	}
	if (! empty($data['expires']) && $data['expires'] !== 'lifetime') {
		$expires = strtotime($data['expires']);
		if ($expires && $expires < time()) {
			if (is_multisite()) {
				$network_status = get_network_option(null, 'ovcd_404_slimmer_license_status', '');
				if ($network_status === 'valid') {
					update_network_option(null, 'ovcd_404_slimmer_license_status', 'invalid');
				} else {
					update_option('ovcd_404_slimmer_license_status', 'invalid');
				}
			} else {
				update_option('ovcd_404_slimmer_license_status', 'invalid');
			}
			return false;
		}
	}
	return true;
}

/**
 * Stats window: FREE = 7 days, PRO = 30 days.
 *
 * @return int
 */
function ovcd_404_slimmer_stats_days() {
	return ovcd_404_slimmer_is_pro() ? 30 : 7;
}

/**
 * Get license data for display (Multisite: network-level first, then site-level).
 *
 * @return array{ 'license_data' => array, 'activated_date' => string }
 */
function ovcd_404_slimmer_get_license_display_data() {
	$license_data   = array();
	$activated_date = '';
	if (is_multisite()) {
		$network_status = get_network_option(null, 'ovcd_404_slimmer_license_status', '');
		if ($network_status === 'valid') {
			$license_data   = get_network_option(null, 'ovcd_404_slimmer_license_data', array());
			$activated_date = get_network_option(null, 'ovcd_404_slimmer_license_activated_date', '');
		}
	}
	if (empty($license_data) && empty($activated_date)) {
		$license_data   = get_option('ovcd_404_slimmer_license_data', array());
		$activated_date = get_option('ovcd_404_slimmer_license_activated_date', '');
	}
	return array(
		'license_data'   => is_array($license_data) ? $license_data : array(),
		'activated_date' => is_string($activated_date) ? $activated_date : '',
	);
}
