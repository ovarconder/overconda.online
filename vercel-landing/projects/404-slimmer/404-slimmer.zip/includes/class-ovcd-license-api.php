<?php
/**
 * License API Client for api.overconda.space
 * Handles activate, verify, deactivate, and periodic re-verification.
 * Multisite and Agency license support.
 *
 * Field names follow API doc (API-ACTIVATE-ENDPOINT.md):
 *   license_key, domain, product_id
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

class OVCD_License_API {

	const API_BASE         = 'https://api.overconda.space/api/v1';
	const PRODUCT_ID       = '404-slimmer';
	const OPTION_KEY       = 'ovcd_404_slimmer_license_key';
	const OPTION_STATUS    = 'ovcd_404_slimmer_license_status';
	const OPTION_DATA      = 'ovcd_404_slimmer_license_data';
	const TRANSIENT_CHECK  = 'ovcd_404_slimmer_license_check';
	const TRANSIENT_TTL    = 86400; // 24 hours
	const CRON_HOOK        = 'ovcd_404_slimmer_license_reverify';

	/**
	 * Standard request headers.
	 *
	 * @return array
	 */
	private static function ovcd_headers() {
		return array(
			'Accept'       => 'application/json',
			'Content-Type' => 'application/x-www-form-urlencoded',
			'User-Agent'   => 'Overconda-404-Slimmer/' . OVCD_404_SLIMMER_VERSION,
		);
	}

	/**
	 * Build common body fields used by all license endpoints.
	 *
	 * @param string $license_key License key.
	 * @return array
	 */
	private static function ovcd_base_body($license_key) {
		$body = array(
			'license_key' => $license_key,
			'domain'      => get_site_url(),
			'product_id'  => self::PRODUCT_ID,
		);
		if (is_multisite()) {
			$body['network_id']   = get_current_network_id();
			$body['site_id']      = get_current_blog_id();
			$body['is_multisite'] = true;
		}
		return $body;
	}

	/**
	 * Send POST request to a license API endpoint.
	 *
	 * @param string $endpoint Endpoint name (e.g. 'activate', 'verify', 'deactivate').
	 * @param array  $body     POST body.
	 * @return array|WP_Error  Decoded JSON or WP_Error.
	 */
	private static function ovcd_post($endpoint, array $body) {
		$url = self::API_BASE . '/' . ltrim($endpoint, '/');

		if (defined('WP_DEBUG') && WP_DEBUG) {
			$debug = $body;
			if (isset($debug['license_key']) && is_string($debug['license_key'])) {
				$len = strlen($debug['license_key']);
				$debug['license_key'] = $len > 8
					? substr($debug['license_key'], 0, 4) . '…' . substr($debug['license_key'], -4)
					: '***';
			}
			error_log('[OVCD 404 Slimmer] API POST ' . $url . ' body=' . wp_json_encode($debug));
		}

		$response = wp_remote_post($url, array(
			'timeout' => 15,
			'body'    => $body,
			'headers' => self::ovcd_headers(),
		));

		if (is_wp_error($response)) {
			return $response;
		}

		$code     = wp_remote_retrieve_response_code($response);
		$body_raw = wp_remote_retrieve_body($response);
		$decoded  = json_decode($body_raw, true);

		// Detect PHP error output masquerading as 200
		$looks_like_error = $body_raw !== '' && (
			strpos($body_raw, 'Fatal error') !== false
			|| strpos($body_raw, 'Warning:') !== false
			|| strpos($body_raw, 'Parse error') !== false
		);
		if (($code >= 200 && $code < 300) && ($decoded === null || $looks_like_error)) {
			return new WP_Error(
				'ovcd_api_invalid_response',
				__('License server returned an invalid response. Please try again later or contact support.', '404-slimmer'),
				array('code' => $code)
			);
		}

		if ($code < 200 || $code >= 300) {
			$message = is_array($decoded) && isset($decoded['message'])
				? $decoded['message']
				: __('License server error.', '404-slimmer');
			$error_data = array('code' => $code);
			if (is_array($decoded)) {
				$ec = isset($decoded['error_code']) ? $decoded['error_code'] : (isset($decoded['code']) ? $decoded['code'] : '');
				if ($ec !== '') {
					$error_data['error_code'] = sanitize_text_field($ec);
				}
			}
			return new WP_Error('ovcd_api_http', $message, $error_data);
		}

		return is_array($decoded) ? $decoded : array();
	}

	// ------------------------------------------------------------------
	//  Public API methods
	// ------------------------------------------------------------------

	/**
	 * Activate license key with the API.
	 *
	 * @param string $license_key License key.
	 * @return array|WP_Error Decoded JSON or WP_Error.
	 */
	public static function ovcd_activate($license_key) {
		$license_key = sanitize_text_field($license_key);
		if (empty($license_key)) {
			return new WP_Error('ovcd_license_empty', __('License key is required.', '404-slimmer'));
		}
		return self::ovcd_post('activate', self::ovcd_base_body($license_key));
	}

	/**
	 * Verify that a stored license key is still valid.
	 *
	 * @param string $license_key License key.
	 * @return array|WP_Error Decoded JSON or WP_Error.
	 */
	public static function ovcd_verify($license_key) {
		$license_key = sanitize_text_field($license_key);
		if (empty($license_key)) {
			return new WP_Error('ovcd_license_empty', __('License key is required.', '404-slimmer'));
		}
		return self::ovcd_post('verify', self::ovcd_base_body($license_key));
	}

	/**
	 * Notify API that this site is deactivating the license.
	 *
	 * @param string $license_key License key.
	 * @return array|WP_Error Decoded JSON or WP_Error.
	 */
	public static function ovcd_deactivate($license_key) {
		$license_key = sanitize_text_field($license_key);
		if (empty($license_key)) {
			return new WP_Error('ovcd_license_empty', __('License key is required.', '404-slimmer'));
		}
		return self::ovcd_post('deactivate', self::ovcd_base_body($license_key));
	}

	// ------------------------------------------------------------------
	//  AUTO-ACCEPT / AUTO-APPROVE ENGINE
	//  - Auto-activate on plugin load if license key is found in DB or wp-config
	//  - Auto-verify via cron (every 24h)
	//  - Auto-deactivate on plugin uninstall
	// ------------------------------------------------------------------

	/**
	 * Run the auto-accept engine on every plugins_loaded.
	 *
	 * Auto-activates if:
	 *   1. A license key exists in the database (stored via AJAX or wp-config)
	 *   2. The status is NOT 'valid' yet (fresh install or expired)
	 *   3. We haven't tried auto-activating recently (transient prevents spam)
	 *
	 * Also checks for OVCD_404_LICENSE_KEY constant (wp-config.php).
	 */
	public static function ovcd_auto_engine() {
		// 1. Check for wp-config constant (overrides everything)
		if (defined('OVCD_404_LICENSE_KEY') && OVCD_404_LICENSE_KEY !== '') {
			$const_key = OVCD_404_LICENSE_KEY;
			$stored_key = self::ovcd_get_stored_key();
			$stored_status = self::ovcd_get_stored_status();

			// If constant key is different from stored, or stored is not valid → auto-activate
			if ($const_key !== $stored_key || $stored_status !== 'valid') {
				self::ovcd_auto_activate($const_key);
			}
			return; // wp-config key always takes precedence
		}

		// 2. Check stored key
		$key = self::ovcd_get_stored_key();
		if (empty($key)) {
			return;
		}

		$status = self::ovcd_get_stored_status();
		if ($status === 'valid') {
			return; // already valid
		}

		// 3. Throttle: only try auto-activate once per 6 hours
		$transient = 'ovcd_auto_activate_try';
		if (get_transient($transient)) {
			return;
		}
		set_transient($transient, true, 6 * HOUR_IN_SECONDS);

		self::ovcd_auto_activate($key);
	}

	/**
	 * Internal: perform auto-activation and save result.
	 *
	 * @param string $license_key The key to activate.
	 */
	private static function ovcd_auto_activate($license_key) {
		$result = self::ovcd_activate($license_key);
		$network_level = is_multisite() && is_network_admin();

		if (is_wp_error($result)) {
			// Network error or invalid license — don't save as valid, but don't wipe stored key either
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[OVCD 404 Slimmer] Auto-activate failed: ' . $result->get_error_message());
			}
			return;
		}

		$valid = (isset($result['success']) && $result['success'] === true)
			|| (isset($result['valid']) && $result['valid'] === true);

		if ($valid) {
			$license_data = array(
				'license_type' => isset($result['license_type']) ? sanitize_text_field($result['license_type']) : 'Personal',
			);
			if (!empty($result['expires'])) {
				$license_data['expires'] = sanitize_text_field($result['expires']);
			}
			$activated_at = isset($result['activated_at']) ? sanitize_text_field($result['activated_at']) : current_time('mysql');

			self::ovcd_save_license_result($license_key, true, $license_data, $network_level);
			self::ovcd_save_activated_date($activated_at, $network_level);

			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[OVCD 404 Slimmer] Auto-activate successful for key: ' . substr($license_key, 0, 4) . '…');
			}
		}
	}

	/**
	 * Save activated_date to option/network option.
	 *
	 * @param string $date          MySQL datetime string.
	 * @param bool   $network_level Use network option.
	 */
	private static function ovcd_save_activated_date($date, $network_level = false) {
		if ($network_level && is_multisite()) {
			update_network_option(null, 'ovcd_404_slimmer_license_activated_date', $date);
		} else {
			update_option('ovcd_404_slimmer_license_activated_date', $date);
		}
	}

	/**
	 * Auto-deactivate on plugin uninstall: notify API server.
	 */
	public static function ovcd_auto_deactivate_on_uninstall() {
		$key = self::ovcd_get_stored_key();
		if (! empty($key)) {
			// Best-effort; ignore errors (server may be down)
			self::ovcd_deactivate($key);
		}

		// Wipe all license options
		$options = array(
			self::OPTION_KEY,
			self::OPTION_STATUS,
			self::OPTION_DATA,
			'ovcd_404_slimmer_license_activated_date',
			'ovcd_404_slimmer_settings',
		);

		foreach ($options as $opt) {
			delete_option($opt);
			if (is_multisite()) {
				delete_network_option(null, $opt);
			}
		}

		delete_transient(self::TRANSIENT_CHECK);
		delete_transient('ovcd_auto_activate_try');
	}

	// ------------------------------------------------------------------
	//  Cron: periodic re-verification (every 24 h)
	// ------------------------------------------------------------------

	/**
	 * Schedule the daily license re-verification cron if not already scheduled.
	 * Call this from plugin init (plugins_loaded).
	 */
	public static function ovcd_schedule_reverify() {
		if (! wp_next_scheduled(self::CRON_HOOK)) {
			wp_schedule_event(time() + self::TRANSIENT_TTL, 'daily', self::CRON_HOOK);
		}
	}

	/**
	 * Unschedule the cron (call on deactivation).
	 */
	public static function ovcd_unschedule_reverify() {
		$ts = wp_next_scheduled(self::CRON_HOOK);
		if ($ts) {
			wp_unschedule_event($ts, self::CRON_HOOK);
		}
	}

	/**
	 * Cron callback: re-verify the stored license key. Invalidate if API says invalid.
	 * This is the AUTO-APPROVE cron — it automatically invalidates expired licenses.
	 */
	public static function ovcd_cron_reverify() {
		$key = self::ovcd_get_stored_key();
		if (empty($key) || self::ovcd_get_stored_status() !== 'valid') {
			return;
		}

		$result = self::ovcd_verify($key);

		if (is_wp_error($result)) {
			// Network error — don't punish the user, try again tomorrow
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[OVCD 404 Slimmer] Cron reverify network error, will retry: ' . $result->get_error_message());
			}
			return;
		}

		$valid = (isset($result['success']) && $result['success'] === true)
			|| (isset($result['valid']) && $result['valid'] === true);

		if ($valid) {
			// Update license data (expires, etc.) in case of renewal
			$license_data = self::ovcd_get_stored_data();
			if (!empty($result['expires'])) {
				$license_data['expires'] = sanitize_text_field($result['expires']);
			}
			if (!empty($result['license_type'])) {
				$license_data['license_type'] = sanitize_text_field($result['license_type']);
			}
			$network_level = is_multisite() && is_network_admin();
			self::ovcd_save_license_result($key, true, $license_data, $network_level);
		} else {
			// Auto-invalidate: license expired, revoked, or domain mismatch
			$network_level = is_multisite() && is_network_admin();
			self::ovcd_save_license_result('', false, array(), $network_level);

			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[OVCD 404 Slimmer] Cron reverify: license auto-invalidated.');
			}
		}
	}

	// ------------------------------------------------------------------
	//  Helpers: stored data
	// ------------------------------------------------------------------

	/**
	 * Get the domain string sent to the API (full URL from get_site_url).
	 *
	 * @return string
	 */
	public static function ovcd_get_site_url() {
		return get_site_url();
	}

	/**
	 * @return string 'valid'|'invalid'|''
	 */
	public static function ovcd_get_stored_status() {
		return (string) get_option(self::OPTION_STATUS, '');
	}

	/**
	 * @return array
	 */
	public static function ovcd_get_stored_data() {
		$data = get_option(self::OPTION_DATA, array());
		return is_array($data) ? $data : array();
	}

	/**
	 * @return string Stored license key (or empty).
	 */
	public static function ovcd_get_stored_key() {
		return (string) get_option(self::OPTION_KEY, '');
	}

	/**
	 * Check if license type allows multiple sites (Agency/Freelance).
	 *
	 * @param array|null $license_data Optional; uses stored if null.
	 * @return bool
	 */
	public static function ovcd_is_agency_license($license_data = null) {
		if ($license_data === null) {
			$license_data = self::ovcd_get_stored_data();
		}
		$type = isset($license_data['license_type']) ? strtolower((string) $license_data['license_type']) : '';
		return in_array($type, array('agency', 'freelance', 'developer'), true);
	}

	/**
	 * Save license result to options. Multisite: network options when $network_level true.
	 *
	 * @param string $key           License key.
	 * @param bool   $valid         Valid flag.
	 * @param array  $data          Optional payload.
	 * @param bool   $network_level Use network options.
	 */
	public static function ovcd_save_license_result($key, $valid, $data = array(), $network_level = false) {
		$status = $valid ? 'valid' : 'invalid';
		$data   = is_array($data) ? $data : array();
		if ($network_level && is_multisite()) {
			update_network_option(null, self::OPTION_KEY, $valid ? $key : '');
			update_network_option(null, self::OPTION_STATUS, $status);
			update_network_option(null, self::OPTION_DATA, $data);
			delete_network_transient(self::TRANSIENT_CHECK);
			return;
		}
		update_option(self::OPTION_KEY, $valid ? $key : '');
		update_option(self::OPTION_STATUS, $status);
		update_option(self::OPTION_DATA, $data);
		delete_transient(self::TRANSIENT_CHECK);
	}
}
