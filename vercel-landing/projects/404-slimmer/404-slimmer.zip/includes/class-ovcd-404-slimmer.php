<?php
/**
 * Main Core Class for 404 Slimmer
 *
 * Handles early 404 interception, statistics tracking, and admin functionality
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Core Plugin Class
 */
class OVCD_404_Slimmer_Core {

	/**
	 * Plugin instance
	 *
	 * @var OVCD_404_Slimmer_Core
	 */
	private static $instance = null;

	/**
	 * Statistics file path
	 *
	 * @var string
	 */
	private $stats_file;

	/**
	 * Blocked file extensions
	 *
	 * @var array
	 */
	private $blocked_extensions = array(
		'php', 'bak', 'env', 'sql', 'log', 'txt', 'old', 'tmp',
		'conf', 'config', 'ini', 'xml', 'json', 'yml', 'yaml'
	);

	/**
	 * Blocked file patterns (for bots scanning common vulnerable files)
	 *
	 * @var array
	 */
	private $blocked_patterns = array(
		'wp-config', 'phpinfo', 'test', 'admin', 'login', 'xmlrpc',
		'readme', 'license', 'changelog', '.htaccess', 'web.config'
	);

	/**
	 * Whether the site has a valid PRO license.
	 *
	 * @return bool
	 */
	public function is_licensed() {
		/**
		 * Filter whether PRO features are available.
		 * A PRO add-on can hook here and return true.
		 *
		 * @since 1.0.0
		 * @param bool $is_pro Whether PRO features are enabled.
		 */
		return (bool) apply_filters( 'ovcd_404_slimmer_is_pro', false );
	}

	/**
	 * Get plugin instance
	 *
	 * @return OVCD_404_Slimmer_Core
	 */
	public static function get_instance() {
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		$ovcd_upload_dir = wp_upload_dir();
		$ovcd_base_dir   = ! empty( $ovcd_upload_dir['basedir'] ) ? $ovcd_upload_dir['basedir'] : WP_CONTENT_DIR;
		$this->stats_file = $ovcd_base_dir . '/ovcd-404-slimmer/stats.json';
		$this->migrate_legacy_stats_file();
		$this->init();
	}

	/**
	 * Migrate stats file from legacy wp-content root to protected subdirectory.
	 *
	 * @return void
	 */
	private function migrate_legacy_stats_file() {
		$legacy = WP_CONTENT_DIR . '/ovcd-404-slimmer-stats.json';
		if (file_exists($legacy) && ! file_exists($this->stats_file)) {
			$dir = dirname($this->stats_file);
			if (! file_exists($dir)) {
				wp_mkdir_p($dir);
			}
			$this->protect_stats_directory($dir);
			@rename($legacy, $this->stats_file);
		}
	}

	/**
	 * Create .htaccess and index.php inside the stats directory to block direct access.
	 *
	 * @param string $dir Directory path.
	 * @return void
	 */
	private function protect_stats_directory($dir) {
		$htaccess = $dir . '/.htaccess';
		if (! file_exists($htaccess)) {
			file_put_contents($htaccess, "Order deny,allow\nDeny from all\n");
		}
		$index = $dir . '/index.php';
		if (! file_exists($index)) {
			file_put_contents($index, "<?php\n// Silence is golden.\n");
		}
	}

	/**
	 * Load plugin textdomain.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'404-slimmer',
			false,
			dirname( plugin_basename( __FILE__ ), 2 ) . '/languages'
		);
	}

	/**
	 * Initialize plugin
	 *
	 * @return void
	 */
	private function init() {
		// Load textdomain for internationalization.
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ), 0 );

		// Early 404 interception - hook at plugins_loaded with high priority
		add_action( 'plugins_loaded', array( $this, 'intercept_404_early' ), 1 );

		// Admin functionality
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		// AJAX handlers for statistics
		add_action( 'wp_ajax_ovcd_404_get_stats', array( $this, 'ajax_get_stats' ) );
		add_action( 'wp_ajax_ovcd_404_reset_stats', array( $this, 'ajax_reset_stats' ) );
		add_action( 'wp_ajax_ovcd_404_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_ovcd_404_restore_default', array( $this, 'ajax_restore_default' ) );

		// Smart redirect for real users on 404 (after WP has set is_404)
		add_action( 'template_redirect', array( $this, 'maybe_redirect_404_real_user' ), 5 );
		// Slim 404: minimal HTML if path is in blocked list
		add_action( 'template_redirect', array( $this, 'maybe_slim_404_blocked_path' ), 3 );
		// Slim 404 template: lightweight output instead of full theme
		add_filter( 'template_include', array( $this, 'filter_slim_404_template' ), 99 );

		// Allow PRO add-on to register additional AJAX handlers or hooks
		do_action( 'ovcd_404_slimmer_core_init', $this );
	}

	/**
	 * Check if current request is whitelisted (path or IP).
	 *
	 * @param string $path Request path
	 * @return bool
	 */
	private function is_whitelisted($path) {
		if ( ! apply_filters( 'ovcd_404_slimmer_is_pro', false ) ) {
			return false; // Whitelist = PRO only
		}
		$paths = get_option('ovcd_404_slimmer_whitelist_paths', '');
		$ips   = get_option('ovcd_404_slimmer_whitelist_ips', '');
		$path  = trim($path, '/');

		if (! empty($paths)) {
			$list = array_map('trim', array_filter(explode("\n", $paths)));
			foreach ($list as $allowed) {
				$allowed = trim($allowed, '/');
				if ($allowed !== '' && (strpos($path, $allowed) === 0 || $path === $allowed)) {
					return true;
				}
			}
		}

		if (! empty($ips)) {
			$client_ip = $this->get_client_ip();
			$list      = array_map('trim', array_filter(explode("\n", $ips)));
			foreach ($list as $allowed_ip) {
				if ($allowed_ip !== '' && $client_ip === $allowed_ip) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Get client IP (respecting proxies).
	 *
	 * @return string
	 */
	private function get_client_ip() {
		$keys = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
		foreach ($keys as $key) {
			if (! empty($_SERVER[ $key ])) {
				$ip = sanitize_text_field(wp_unslash($_SERVER[ $key ]));
				$ip = strpos($ip, ',') !== false ? trim(explode(',', $ip)[0]) : $ip;
				if (filter_var($ip, FILTER_VALIDATE_IP)) {
					return $ip;
				}
			}
		}
		return '';
	}

	/**
	 * Smart Auto-Redirect: if 404 and real user (not bot), and request is not image/css/js, redirect to home or custom URL.
	 */
	public function maybe_redirect_404_real_user() {
		if (! is_404()) {
			return;
		}
		if (! get_option('ovcd_404_slimmer_redirect_enabled', false)) {
			return;
		}
		if ($this->is_bot()) {
			return;
		}
		// Do not redirect asset requests (image, css, js) — let them 404 normally
		if ($this->is_asset_request()) {
			return;
		}
		$url = get_option('ovcd_404_slimmer_redirect_url', '');
		$url = $url !== '' ? $url : home_url('/');
		$url = esc_url_raw($url);
		if ($url !== '') {
			wp_safe_redirect($url, 302, 'OVCD 404 Slimmer');
			exit;
		}
	}

	/**
	 * Check if current request looks like an asset (image, css, js).
	 *
	 * @return bool
	 */
	private function is_asset_request() {
		$uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
		$path = wp_parse_url($uri, PHP_URL_PATH);
		if (empty($path)) {
			return false;
		}
		$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
		$asset_extensions = array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'ico', 'css', 'js', 'woff', 'woff2', 'ttf', 'eot' );
		return in_array($ext, $asset_extensions, true);
	}

	/**
	 * Slim 404: if path is in blocked list, serve minimal HTML and exit (placeholder).
	 */
	public function maybe_slim_404_blocked_path() {
		if (! is_404()) {
			return;
		}
		$path = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
		$path = trim(wp_parse_url($path, PHP_URL_PATH), '/');
		if (empty($path)) {
			return;
		}
		$blocked_list = $this->get_slim_404_blocked_list();
		foreach ($blocked_list as $blocked) {
			$blocked = trim($blocked, '/');
			if ($blocked !== '' && (strpos($path, $blocked) === 0 || $path === $blocked)) {
				status_header(404);
				nocache_headers();
				header('Content-Type: text/html; charset=UTF-8');
				echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>404 Not Found</title></head><body><h1>404 Not Found</h1><p>OVCD Slim 404</p></body></html>';
				exit;
			}
		}
	}

	/**
	 * Get list of paths that receive slim 404 response (placeholder — can be option later).
	 *
	 * @return array
	 */
	private function get_slim_404_blocked_list() {
		$list = get_option('ovcd_404_slimmer_slim_blocked_paths', '');
		if ($list !== '') {
			return array_map('trim', array_filter(explode("\n", $list)));
		}
		return array();
	}

	/**
	 * Simple bot detection from User-Agent.
	 *
	 * @return bool True if likely a bot/crawler
	 */
	private function is_bot() {
		$ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
		if ($ua === '') {
			return true; // No UA: treat as bot to avoid redirecting unknown clients
		}
		$bot_patterns = array('bot', 'crawl', 'spider', 'slurp', 'feed', 'curl', 'wget', 'python', 'java/', 'php', 'scanner', 'headless');
		$ua_lower     = strtolower($ua);
		foreach ($bot_patterns as $pattern) {
			if (strpos($ua_lower, $pattern) !== false) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Use slim 404 template when enabled to avoid heavy theme load.
	 *
	 * @param string $template Current template path
	 * @return string
	 */
	public function filter_slim_404_template($template) {
		if (! is_404()) {
			return $template;
		}
		if (! get_option('ovcd_404_slimmer_use_slim_404', true)) {
			return $template;
		}
		$slim = OVCD_404_SLIMMER_PLUGIN_DIR . 'templates/slim-404.php';
		if (file_exists($slim)) {
			return $slim;
		}
		return $template;
	}

	/**
	 * Early 404 Interceptor
	 * 
	 * Intercepts requests for non-existent files before WordPress loads database and theme hooks
	 *
	 * @return void
	 */
	public function intercept_404_early() {
		// Only run on frontend requests
		if (is_admin() || wp_doing_ajax() || wp_doing_cron() || defined('WP_CLI')) {
			return;
		}

		// Get requested URI
		$request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
		if (empty($request_uri)) {
			return;
		}

		// Parse URI to get file path
		$parsed_url = wp_parse_url($request_uri);
		$path = isset($parsed_url['path']) ? $parsed_url['path'] : '';
		if (empty($path) || $path === '/') {
			return;
		}

		// Whitelist: skip blocking for allowed paths or IPs
		if ($this->is_whitelisted($path)) {
			return;
		}

		// Extract file extension
		$path_info = pathinfo($path);
		$extension = isset($path_info['extension']) ? strtolower($path_info['extension']) : '';
		$filename = isset($path_info['filename']) ? strtolower($path_info['filename']) : '';
		$basename = isset($path_info['basename']) ? strtolower($path_info['basename']) : '';

		// Check if file exists
		$file_path = ABSPATH . ltrim($path, '/');
		
		// If file doesn't exist, check if it matches blocked patterns
		if (!file_exists($file_path)) {
			$should_block = false;

			// Check blocked extensions
			if (!empty($extension) && in_array($extension, $this->blocked_extensions, true)) {
				$should_block = true;
			}

			// Check blocked patterns in filename
			foreach ($this->blocked_patterns as $pattern) {
				if (strpos($filename, $pattern) !== false || strpos($basename, $pattern) !== false) {
					$should_block = true;
					break;
				}
			}

			// Block the request if it matches criteria
			if ($should_block) {
				$this->log_blocked_request($path);
				$this->send_404_response();
			}
		}
	}

	/**
	 * Send 404 response and die
	 *
	 * @return void
	 */
	private function send_404_response() {
		// Set 404 status
		status_header(404);
		nocache_headers();
		
		// Send minimal 404 response
		header('Content-Type: text/html; charset=UTF-8');
		
		// Output minimal HTML
		echo '<!DOCTYPE html><html><head><title>404 Not Found</title></head><body><h1>404 Not Found</h1></body></html>';
		
		// Stop execution immediately
		die();
	}

	/**
	 * Log blocked request to statistics
	 *
	 * @param string $path Requested path
	 * @return void
	 */
	private function log_blocked_request($path) {
		$stats = $this->get_stats();
		
		$stats['total_blocked'] = isset($stats['total_blocked']) ? $stats['total_blocked'] + 1 : 1;
		$stats['last_blocked'] = current_time('mysql');
		$stats['last_path'] = $path;
		
		// Track daily statistics
		$today = current_time('Y-m-d');
		if (!isset($stats['daily'][$today])) {
			$stats['daily'][$today] = 0;
		}
		$stats['daily'][$today]++;
		
		// Keep only last 30 days
		if (count($stats['daily']) > 30) {
			$stats['daily'] = array_slice($stats['daily'], -30, 30, true);
		}
		
		$this->save_stats($stats);

		// Trigger webhook notification (PRO feature)
		if ( $this->is_licensed() && get_option( 'ovcd_404_slimmer_webhook_enabled', false ) ) {
			/**
			 * Fires when a request is blocked and webhook notifications are enabled.
			 * A PRO add-on should hook here to send the webhook.
			 *
			 * @since 1.0.0
			 * @param string $path The blocked request path.
			 * @param array  $stats The current statistics.
			 */
			do_action( 'ovcd_404_slimmer_webhook_blocked', $path, $stats );
		}
	}

	// Webhook handler removed - see ovcd_404_slimmer_webhook_blocked action.

	/**
	 * Get statistics (FREE: last 7 days only; PRO: up to 30 days).
	 *
	 * @return array
	 */
	public function get_stats() {
		if (!file_exists($this->stats_file)) {
			return array(
				'total_blocked' => 0,
				'last_blocked' => '',
				'last_path' => '',
				'daily' => array(),
				'created' => current_time('mysql')
			);
		}

		$content = file_get_contents($this->stats_file);
		$stats = json_decode($content, true);
		$stats = is_array($stats) ? $stats : array();

		$max_days = (int) apply_filters( 'ovcd_404_slimmer_stats_days', 7 );
		if ( ! empty( $stats['daily'] ) && $max_days < 30 ) {
			$stats['daily'] = array_slice( $stats['daily'], - $max_days, $max_days, true );
			$stats['total_blocked'] = array_sum( $stats['daily'] );
		}

		return $stats;
	}

	/**
	 * Save statistics
	 *
	 * @param array $stats Statistics data
	 * @return bool
	 */
	private function save_stats($stats) {
		$dir = dirname($this->stats_file);
		if (!file_exists($dir)) {
			wp_mkdir_p($dir);
			$this->protect_stats_directory($dir);
		}
		
		return file_put_contents($this->stats_file, wp_json_encode($stats, JSON_PRETTY_PRINT)) !== false;
	}

	/**
	 * Calculate Server Load Reduced metric: (Total Blocked * 0.05) formatted to 2 decimal places.
	 *
	 * @param int $blocked_requests Number of blocked requests
	 * @return float
	 */
	public function calculate_load_reduction($blocked_requests) {
		if ($blocked_requests <= 0) {
			return 0.0;
		}
		return round((float) $blocked_requests * 0.05, 2);
	}

	/**
	 * Get stats for UI display: returns real stats if available,
	 * or empty placeholder stats if no data yet.
	 * FREE: 7 days, PRO: 30 days.
	 *
	 * @return array{ total_blocked: int, daily: array, load_reduction: float, last_blocked: string, last_path: string }
	 */
	public function get_stats_for_display() {
		$real_stats = $this->get_stats();
		$has_real_data = ! empty( $real_stats['daily'] );
		$max_days     = (int) apply_filters( 'ovcd_404_slimmer_stats_days', 7 );

		if ( $has_real_data ) {
			// Use real stats but slice to max allowed days.
			$daily = $real_stats['daily'];
			if ( count( $daily ) > $max_days ) {
				$daily = array_slice( $daily, -$max_days, $max_days, true );
			}
			$total = array_sum( $daily );
			return array(
				'total_blocked'  => $total,
				'daily'          => $daily,
				'load_reduction' => $this->calculate_load_reduction( $total ),
				'last_blocked'   => isset( $real_stats['last_blocked'] ) ? $real_stats['last_blocked'] : '',
				'last_path'      => isset( $real_stats['last_path'] ) ? $real_stats['last_path'] : '',
			);
		}

		// No real data yet — return empty placeholder.
		return array(
			'total_blocked'  => 0,
			'daily'          => array(),
			'load_reduction' => 0.0,
			'last_blocked'   => '',
			'last_path'      => '',
		);
	}

	/**
	 * Get chart data for exactly N days (7 or 30).
	 * Uses real stats only; returns empty array if no data.
	 *
	 * @param int $days Number of days (7 or 30).
	 * @return array Daily keyed by date Y-m-d.
	 */
	public function get_chart_data_for_days($days) {
		$days = (int) $days;
		$days = $days >= 7 && $days <= 30 ? $days : 30;

		$real_stats = $this->get_stats();
		$has_real_data = !empty($real_stats['daily']);

		if ($has_real_data) {
			$daily = $real_stats['daily'];
			if (count($daily) > $days) {
				$daily = array_slice($daily, -$days, $days, true);
			}
			return $daily;
		}

		// No data yet — return empty array
		return array();
	}

	/**
	 * Add admin menu
	 *
	 * @return void
	 */
	public function add_admin_menu() {
		add_menu_page(
			__('404 Slimmer', '404-slimmer'),
			__('404 Slimmer', '404-slimmer'),
			'manage_options',
			'ovcd-404-slimmer',
			array($this, 'render_admin_page'),
			'dashicons-performance',
			30
		);
	}

	/**
	 * Enqueue admin assets
	 *
	 * @param string $hook Current admin page hook
	 * @return void
	 */
	public function enqueue_admin_assets($hook) {
		// Only load on our admin page
		if ($hook !== 'toplevel_page_ovcd-404-slimmer') {
			return;
		}

		// Enqueue CSS
		wp_enqueue_style(
			'ovcd-404-slimmer-admin',
			OVCD_404_SLIMMER_PLUGIN_URL . 'assets/css/ovcd-admin-style.css',
			array(),
			OVCD_404_SLIMMER_VERSION
		);

		// Chart.js for Line chart
		wp_enqueue_script(
			'chart-js',
			'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js',
			array(),
			'4.4.1',
			true
		);

		wp_enqueue_script(
			'ovcd-404-slimmer-charts',
			OVCD_404_SLIMMER_PLUGIN_URL . 'assets/js/ovcd-charts.js',
			array('jquery', 'chart-js'),
			OVCD_404_SLIMMER_VERSION,
			true
		);

		// Chart data: send 30 days so JS can display 7 or 30 based on Free/Pro mode
		$chart_stats    = $this->get_stats_for_display();
		$load_reduction = $chart_stats['load_reduction'];
		$daily_30       = $this->get_chart_data_for_days(30);
		$stats_days     = (int) apply_filters( 'ovcd_404_slimmer_stats_days', 7 );

		wp_localize_script(
			'ovcd-404-slimmer-charts',
			'ovcd404Slimmer',
			array(
				'ajaxUrl'        => admin_url('admin-ajax.php'),
				'nonce'          => wp_create_nonce('ovcd_404_slimmer_nonce'),
				'previewBaseUrl' => home_url('/__ovcd-slim-404-preview__'),
				'chartData'      => array(
					'stats'          => $chart_stats,
					'load_reduction' => $load_reduction,
					'daily_chart'    => $chart_stats['daily'],
					'daily_chart_30' => $daily_30,
					'stats_days'     => $stats_days,
				),
				'i18n'       => array(
					'loading'           => __('Loading...', '404-slimmer'),
					'verifying'         => __('Verifying...', '404-slimmer'),
					'error'             => __('Error loading statistics', '404-slimmer'),
					'confirmReset'      => __('Are you sure you want to reset all statistics? This action cannot be undone.', '404-slimmer'),
					'resetting'         => __('Resetting...', '404-slimmer'),
					'confirmDeactivate' => __('Deactivate this license? You will need to enter a key again to restore Pro features.', '404-slimmer'),
					'proFeature'        => __('PRO Feature', '404-slimmer'),
				),
			)
		);

		// Dashboard inline script (previously hardcoded in admin-dashboard.php).
		$ovcd_inline_js = '
(function() {
	"use strict";
	var STORAGE_KEY = "ovcd_404_preview_mode";
	var wrap = document.getElementById("ovcd-dashboard-wrap");
	var form = document.getElementById("ovcd-settings-form");
	var webhookWrap = document.getElementById("ovcd-webhook-url-wrap");
	var check = document.getElementById("ovcd-webhook-enabled");
	var submitBtn = document.getElementById("ovcd-settings-submit");
	var btnText = submitBtn && submitBtn.querySelector(".ovcd-btn-text");
	var spinner = submitBtn && submitBtn.querySelector(".ovcd-btn-spinner");

	function getPreviewMode() {
		try { return localStorage.getItem(STORAGE_KEY); } catch (e) { return null; }
	}
	function setPreviewMode(mode) {
		try { localStorage.setItem(STORAGE_KEY, mode); } catch (e) {}
	}
	function isProNow() {
		var preview = getPreviewMode();
		if (preview === "free") return false;
		if (preview === "pro") return true;
		return wrap && wrap.getAttribute("data-ovcd-is-pro") === "1";
	}
	function setProInputsEnabled(enabled) {
		var redirectCheck = document.getElementById("ovcd-redirect-enabled");
		var redirectUrl = document.getElementById("ovcd-redirect-url");
		var webhookCheck = document.getElementById("ovcd-webhook-enabled");
		var webhookUrl = document.getElementById("ovcd-webhook-url");
		if (redirectCheck) redirectCheck.disabled = !enabled;
		if (redirectUrl) redirectUrl.disabled = !enabled;
		if (webhookCheck) webhookCheck.disabled = !enabled;
		if (webhookUrl) webhookUrl.disabled = !enabled;
		var wPaths = document.getElementById("ovcd-whitelist-paths");
		var wIps = document.getElementById("ovcd-whitelist-ips");
		if (wPaths) wPaths.disabled = !enabled;
		if (wIps) wIps.disabled = !enabled;
		[ wPaths, wIps ].forEach(function(el) {
			if (el && el.closest) {
				var grp = el.closest(".ovcd-form-group.ovcd-pro-feature");
				if (grp) grp.classList.toggle("ovcd-pro-locked", !enabled);
			}
		});
		wrap.querySelectorAll(".ovcd-style-radio-item.ovcd-pro-feature input.ovcd-slim-style-radio").forEach(function(radio) {
			radio.disabled = !enabled;
		});
		wrap.querySelectorAll(".ovcd-style-option-pro").forEach(function(label) {
			var radio = label.querySelector("input.ovcd-slim-style-radio");
			if (!radio) return;
			radio.disabled = !enabled;
			label.classList.toggle("ovcd-pro-locked", !enabled);
			var lockIcon = label.querySelector(".ovcd-style-lock-icon");
			if (lockIcon) lockIcon.style.display = enabled ? "none" : "";
		});
		if (!enabled) {
			var radio6 = wrap.querySelector(".ovcd-slim-style-radio[value=\"6\"]");
			if (radio6) radio6.checked = true;
		}
	}
	function applyPreviewUI() {
		if (!wrap) return;
		var pro = isProNow();
		var days = pro ? 30 : 7;
		window.ovcdPreviewDays = days;
		wrap.classList.remove("ovcd-preview-as-free", "ovcd-preview-as-pro");
		wrap.classList.add(pro ? "ovcd-preview-as-pro" : "ovcd-preview-as-free");
		setProInputsEnabled(pro);
		var chartTitleWrap = document.getElementById("ovcd-chart-title-wrap");
		var chartTitleText = document.getElementById("ovcd-chart-title-text");
		if (chartTitleText) chartTitleText.textContent = "Daily Blocked Requests (Last " + days + " Days)";
		if (chartTitleWrap) {
			var lockSpan = chartTitleWrap.querySelector(".ovcd-pro-lock-icon");
			var unlockWrap = chartTitleWrap.querySelector(".ovcd-chart-unlock-wrap");
			if (pro) {
				if (lockSpan) lockSpan.remove();
				if (unlockWrap) unlockWrap.remove();
			} else {
				if (!lockSpan) {
					var s = document.createElement("span");
					s.className = "ovcd-pro-lock-icon";
					s.title = "Pro feature";
					s.textContent = "\uD83D\uDD12";
					chartTitleWrap.appendChild(s);
				}
				if (!unlockWrap) {
					var uw = document.createElement("span");
					uw.className = "ovcd-chart-unlock-wrap";
					var link = document.createElement("a");
					link.href = "#ovcd-license-card";
					link.className = "ovcd-chart-unlock-link";
					link.id = "ovcd-chart-unlock-link";
					link.textContent = "Unlock for last 30 days";
					uw.appendChild(link);
					chartTitleWrap.appendChild(uw);
				}
			}
		}
		var exportBtn = document.getElementById("ovcd-export-data");
		if (exportBtn) {
			exportBtn.disabled = !pro;
			var lockInBtn = exportBtn.querySelector(".ovcd-pro-lock-icon");
			if (!pro && !lockInBtn) {
				var lock = document.createElement("span");
				lock.className = "ovcd-pro-lock-icon";
				lock.setAttribute("aria-hidden", "true");
				lock.textContent = "\uD83D\uDD12";
				exportBtn.insertBefore(lock, exportBtn.firstChild);
			} else if (pro && lockInBtn) lockInBtn.remove();
		}
		var exportWrap = wrap.querySelector(".ovcd-actions-export-wrap");
		if (exportWrap) exportWrap.classList.toggle("ovcd-pro-locked", !pro);
		document.querySelectorAll(".ovcd-preview-btn").forEach(function(btn) {
			var isActive = (btn.getAttribute("data-ovcd-preview") === "pro") === pro;
			btn.classList.toggle("ovcd-active", isActive);
			btn.setAttribute("aria-pressed", isActive ? "true" : "false");
		});
		if (window.ovcdProLicenseToggle) {
			window.ovcdProLicenseToggle(pro);
		}
	}
	function bindPreviewToggle() {
		var buttons = document.querySelectorAll(".ovcd-preview-btn");
		buttons.forEach(function(btn) {
			btn.addEventListener("click", function() {
				var mode = this.getAttribute("data-ovcd-preview");
				if (!mode) return;
				setPreviewMode(mode);
				applyPreviewUI();
				if (typeof ovcd404Slimmer !== "undefined" && ovcd404Slimmer.chartData && window.OVCD404Slimmer && window.OVCD404Slimmer.updateChart) {
					window.OVCD404Slimmer.updateChart();
				}
			});
		});
	}
	bindPreviewToggle();
	var saved = getPreviewMode();
	if (saved) {
		setPreviewMode(saved);
	} else {
		window.ovcdPreviewDays = wrap && wrap.getAttribute("data-ovcd-is-pro") === "1" ? 30 : 7;
	}
	applyPreviewUI();
	if (window.OVCD404Slimmer && window.OVCD404Slimmer.updateChart) {
		window.OVCD404Slimmer.updateChart();
	}
	window.ovcdApplyPreviewUI = applyPreviewUI;

	if (check && webhookWrap) {
		check.addEventListener("change", function() {
			webhookWrap.classList.toggle("ovcd-webhook-url-visible", check.checked);
		});
	}
	if (form && submitBtn && btnText && spinner) {
		form.addEventListener("submit", function() {
			submitBtn.disabled = true;
			btnText.textContent = "' . esc_js( __( 'Saving...', '404-slimmer' ) ) . '";
			spinner.style.display = "inline-block";
		});
	}
	var toast = document.getElementById("ovcd-toast-settings-saved");
	if (toast) {
		setTimeout(function() { toast.classList.add("ovcd-toast-hide"); }, 4000);
		setTimeout(function() { toast.remove(); }, 4500);
	}

	function initRestoreButtons() {
		var btns = document.querySelectorAll(".ovcd-restore-default-btn");
		btns.forEach(function(btn) {
			btn.addEventListener("click", function(e) {
				e.preventDefault();
				var field = this.getAttribute("data-ovcd-restore-field");
				if (!field) return;
				restoreField(field, this);
			});
		});
	}
	function restoreField(field, btn) {
		if (!confirm("' . esc_js( __( 'Are you sure you want to restore this field to its default value?', '404-slimmer' ) ) . '")) {
			return;
		}
		var originalHtml = btn.innerHTML;
		btn.disabled = true;
		btn.innerHTML = "' . esc_js( __( 'Restoring...', '404-slimmer' ) ) . '";
		var data = new URLSearchParams();
		data.set("action", "ovcd_404_restore_default");
		data.set("nonce", ovcd404Slimmer.nonce);
		data.set("field", field);
		fetch(ovcd404Slimmer.ajaxUrl, {
			method: "POST",
			headers: { "Content-Type": "application/x-www-form-urlencoded" },
			body: data.toString()
		})
		.then(function(res) { return res.json(); })
		.then(function(response) {
			if (response.success) {
				var inputMap = {
					"ovcd_custom_title": "ovcd-custom-title",
					"ovcd_custom_message": "ovcd-custom-message",
					"ovcd_custom_btn_text": "ovcd-custom-btn-text",
					"ovcd_custom_css": "ovcd-custom-css"
				};
				var inputId = inputMap[field];
				if (inputId) {
					var input = document.getElementById(inputId);
					if (input) input.value = "";
				}
				if (window.OVCD404Slimmer && window.OVCD404Slimmer.showNotice) {
					window.OVCD404Slimmer.showNotice("' . esc_js( __( 'Field restored to default.', '404-slimmer' ) ) . '", "success");
				}
			} else {
				var msg = response.data && response.data.message ? response.data.message : "' . esc_js( __( 'Failed to restore.', '404-slimmer' ) ) . '";
				if (window.OVCD404Slimmer && window.OVCD404Slimmer.showNotice) {
					window.OVCD404Slimmer.showNotice(msg, "error");
				}
			}
			btn.disabled = false;
			btn.innerHTML = originalHtml;
		})
		.catch(function() {
			btn.disabled = false;
			btn.innerHTML = originalHtml;
			if (window.OVCD404Slimmer && window.OVCD404Slimmer.showNotice) {
				window.OVCD404Slimmer.showNotice("' . esc_js( __( 'Network error. Please try again.', '404-slimmer' ) ) . '", "error");
			}
		});
	}
	function initCustomStyleLogic() {
		var cwrap = document.getElementById("ovcd-custom-fields-wrap");
		var radios = document.querySelectorAll(".ovcd-slim-style-radio");
		var baseStyleInput = document.getElementById("ovcd-custom-base-style");
		if (!baseStyleInput || !cwrap) return;
		function toggleCustomFields(show) {
			if (show) {
				cwrap.style.display = "";
				cwrap.querySelectorAll("input, textarea, button.ovcd-restore-default-btn").forEach(function(el) {
					if (el) el.disabled = false;
				});
			} else {
				cwrap.style.display = "none";
				cwrap.querySelectorAll("input, textarea, button.ovcd-restore-default-btn").forEach(function(el) {
					if (el) el.disabled = true;
				});
			}
		}
		radios.forEach(function(radio) {
			radio.addEventListener("change", function() {
				var val = parseInt(this.value, 10);
				if (val === 7) {
					toggleCustomFields(true);
				} else if (val >= 1 && val <= 6) {
					toggleCustomFields(false);
					baseStyleInput.value = val.toString();
				}
			});
		});
		var currentVal = parseInt(document.querySelector(".ovcd-slim-style-radio:checked").value || "6", 10);
		toggleCustomFields(currentVal === 7);
	}
	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", function() {
			initRestoreButtons();
			initCustomStyleLogic();
		});
	} else {
		initRestoreButtons();
		initCustomStyleLogic();
	}
})();
';
		wp_add_inline_script( 'ovcd-404-slimmer-charts', $ovcd_inline_js );
	}

	/**
	 * Render admin page
	 *
	 * @return void
	 */
	public function render_admin_page() {
		// Check user capabilities
		if (!current_user_can('manage_options')) {
			wp_die(__('You do not have sufficient permissions to access this page.', '404-slimmer'));
		}

		// Load template
		$template_path = OVCD_404_SLIMMER_PLUGIN_DIR . 'templates/admin-dashboard.php';
		if (file_exists($template_path)) {
			include $template_path;
		} else {
			echo '<div class="wrap"><h1>' . esc_html__('404 Slimmer', '404-slimmer') . '</h1><p>' . esc_html__('Template file not found.', '404-slimmer') . '</p></div>';
		}
	}

	/**
	 * AJAX handler: Get statistics
	 *
	 * @return void
	 */
	public function ajax_get_stats() {
		// Verify nonce
		check_ajax_referer('ovcd_404_slimmer_nonce', 'nonce');
		
		// Check capabilities
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied.', '404-slimmer')));
		}

		$stats = $this->get_stats();
		$load_reduction = $this->calculate_load_reduction($stats['total_blocked']);
		
		wp_send_json_success(array(
			'stats' => $stats,
			'load_reduction' => $load_reduction
		));
	}

	/**
	 * AJAX handler: Reset statistics
	 *
	 * @return void
	 */
	public function ajax_reset_stats() {
		// Verify nonce
		check_ajax_referer('ovcd_404_slimmer_nonce', 'nonce');
		
		// Check capabilities
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied.', '404-slimmer')));
		}

		$default_stats = array(
			'total_blocked' => 0,
			'last_blocked' => '',
			'last_path' => '',
			'daily' => array(),
			'created' => current_time('mysql')
		);
		
		$this->save_stats($default_stats);
		
		wp_send_json_success(array('message' => __('Statistics reset successfully.', '404-slimmer')));
	}

	/**
	 * AJAX handler: Activate license.
	 * PRO add-on should hook into 'wp_ajax_ovcd_404_verify_license'.
	 *
	 * @return void
	 */
	public function ajax_verify_license() {
		/**
		 * Fires when license activation is requested.
		 * PRO add-on should handle this action.
		 *
		 * @since 1.0.0
		 */
		do_action( 'ovcd_404_slimmer_ajax_verify_license' );
	}

	/**
	 * AJAX handler: Deactivate license.
	 * PRO add-on should hook into 'wp_ajax_ovcd_404_deactivate_license'.
	 *
	 * @return void
	 */
	public function ajax_deactivate_license() {
		/**
		 * Fires when license deactivation is requested.
		 * PRO add-on should handle this action.
		 *
		 * @since 1.0.0
		 */
		do_action( 'ovcd_404_slimmer_ajax_deactivate_license' );
	}

	/**
	 * AJAX handler: Export statistics data as JSON download (PRO only).
	 * PRO add-on should hook into 'wp_ajax_ovcd_404_export_data'.
	 *
	 * @return void
	 */
	public function ajax_export_data() {
		/**
		 * Fires when data export is requested.
		 * PRO add-on should handle this action.
		 *
		 * @since 1.0.0
		 */
		do_action( 'ovcd_404_slimmer_ajax_export_data' );
	}

	/**
	 * AJAX handler: Save settings (redirect, whitelist, slim 404, custom template).
	 *
	 * @return void
	 */
	public function ajax_save_settings() {
		check_ajax_referer('ovcd_404_slimmer_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied.', '404-slimmer')));
		}

		$redirect_url     = isset($_POST['ovcd_redirect_url']) ? esc_url_raw(wp_unslash($_POST['ovcd_redirect_url'])) : '';
		$redirect_enabled = isset($_POST['ovcd_redirect_enabled']) && $_POST['ovcd_redirect_enabled'] === '1';
		$whitelist_paths  = isset($_POST['ovcd_whitelist_paths']) ? sanitize_textarea_field(wp_unslash($_POST['ovcd_whitelist_paths'])) : '';
		$whitelist_ips    = isset($_POST['ovcd_whitelist_ips']) ? sanitize_textarea_field(wp_unslash($_POST['ovcd_whitelist_ips'])) : '';
		$use_slim_404     = isset($_POST['ovcd_use_slim_404']) && $_POST['ovcd_use_slim_404'] === '1';
		$webhook_url      = isset($_POST['ovcd_webhook_url']) ? esc_url_raw(wp_unslash($_POST['ovcd_webhook_url'])) : '';
		$webhook_enabled  = isset($_POST['ovcd_webhook_enabled']) && $_POST['ovcd_webhook_enabled'] === '1';
		// PRO-only: force disable webhook for FREE
		if ( ! apply_filters( 'ovcd_404_slimmer_is_pro', false ) ) {
			$webhook_enabled = false;
			$webhook_url     = '';
		}
		// รองรับทั้งชื่อ ovcd_slim_template_style (จาก AJAX) และ slim_style (จาก form)
		$slim_style = isset($_POST['ovcd_slim_template_style']) ? (int) $_POST['ovcd_slim_template_style'] : (isset($_POST['slim_style']) ? (int) $_POST['slim_style'] : 6);
		$slim_style = max(1, min(7, $slim_style));
		if ( ! apply_filters( 'ovcd_404_slimmer_is_pro', false ) ) {
			$slim_style = 6; // FREE: White template only
		}

		// === Custom 404 template fields ===
		$custom_css     = isset($_POST['ovcd_custom_css']) ? sanitize_textarea_field(wp_unslash($_POST['ovcd_custom_css'])) : '';
		$custom_title   = isset($_POST['ovcd_custom_title']) ? sanitize_text_field(wp_unslash($_POST['ovcd_custom_title'])) : '';
		$custom_message = isset($_POST['ovcd_custom_message']) ? sanitize_text_field(wp_unslash($_POST['ovcd_custom_message'])) : '';
		$custom_btn     = isset($_POST['ovcd_custom_btn_text']) ? sanitize_text_field(wp_unslash($_POST['ovcd_custom_btn_text'])) : '';
		$custom_base_style = isset($_POST['ovcd_custom_base_style']) ? (int) $_POST['ovcd_custom_base_style'] : 6;
		$custom_base_style = max(1, min(6, $custom_base_style));

		update_option('ovcd_404_slimmer_slim_template_style', $slim_style);
		update_option('ovcd_404_slimmer_redirect_url', $redirect_url);
		update_option('ovcd_404_slimmer_redirect_enabled', $redirect_enabled);
		update_option('ovcd_404_slimmer_whitelist_paths', $whitelist_paths);
		update_option('ovcd_404_slimmer_whitelist_ips', $whitelist_ips);
		update_option('ovcd_404_slimmer_use_slim_404', $use_slim_404);
		update_option('ovcd_404_slimmer_webhook_url', $webhook_url);
		update_option('ovcd_404_slimmer_webhook_enabled', $webhook_enabled);
		update_option('ovcd_404_slimmer_custom_css', $custom_css);
		update_option('ovcd_404_slimmer_custom_title', $custom_title);
		update_option('ovcd_404_slimmer_custom_message', $custom_message);
		update_option('ovcd_404_slimmer_custom_btn_text', $custom_btn);
		update_option('ovcd_404_slimmer_custom_base_style', $custom_base_style);

		// Sync single settings array สำหรับ dashboard และ form POST
		$settings = get_option('ovcd_404_slimmer_settings', array());
		if (is_array($settings)) {
			$settings['slim_style'] = $slim_style;
			$settings['whitelist_paths'] = $whitelist_paths;
			$settings['whitelist_ips'] = $whitelist_ips;
			$settings['redirect_url'] = $redirect_url;
			$settings['enable_redirect'] = $redirect_enabled;
			$settings['use_slim_template'] = $use_slim_404;
			$settings['webhook_url'] = $webhook_url;
			$settings['enable_webhook'] = $webhook_enabled;
			$settings['custom_css'] = $custom_css;
			$settings['custom_title'] = $custom_title;
			$settings['custom_message'] = $custom_message;
			$settings['custom_btn_text'] = $custom_btn;
			$settings['custom_base_style'] = $custom_base_style;
			update_option('ovcd_404_slimmer_settings', $settings);
		}

		wp_send_json_success(array('message' => __('Settings saved.', '404-slimmer')));
	}

	/**
	 * AJAX handler: Restore a single custom 404 template field to its default (empty).
	 *
	 * @return void
	 */
	public function ajax_restore_default() {
		check_ajax_referer('ovcd_404_slimmer_nonce', 'nonce');
		if (! current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied.', '404-slimmer')));
		}

		$field = isset($_POST['field']) ? sanitize_key(wp_unslash($_POST['field'])) : '';
		$allowed_fields = array(
			'ovcd_custom_title',
			'ovcd_custom_message',
			'ovcd_custom_btn_text',
			'ovcd_custom_css',
			'ovcd_custom_base_style',
		);
		if (! in_array($field, $allowed_fields, true)) {
			wp_send_json_error(array('message' => __('Invalid field.', '404-slimmer')));
		}

		// Map field name to option key
		$option_map = array(
			'ovcd_custom_title'   => 'ovcd_404_slimmer_custom_title',
			'ovcd_custom_message' => 'ovcd_404_slimmer_custom_message',
			'ovcd_custom_btn_text'=> 'ovcd_404_slimmer_custom_btn_text',
			'ovcd_custom_css'     => 'ovcd_404_slimmer_custom_css',
			'ovcd_custom_base_style' => 'ovcd_404_slimmer_custom_base_style',
		);
		$option_key = $option_map[ $field ];

		// Clear the option (set to empty string = use default)
		update_option($option_key, '');

		// Also sync merged settings array
		$settings = get_option('ovcd_404_slimmer_settings', array());
		if (is_array($settings)) {
			$settings_key_map = array(
				'ovcd_custom_title'   => 'custom_title',
				'ovcd_custom_message' => 'custom_message',
				'ovcd_custom_btn_text'=> 'custom_btn_text',
				'ovcd_custom_css'     => 'custom_css',
				'ovcd_custom_base_style' => 'custom_base_style',
			);
			$sk = $settings_key_map[ $field ];
			$settings[ $sk ] = '';
			update_option('ovcd_404_slimmer_settings', $settings);
		}

		wp_send_json_success(array(
			'message'  => __('Field restored to default.', '404-slimmer'),
			'field'    => $field,
			'new_value' => '',
		));
	}

	/**
	 * Check license validity.
	 * PRO add-on should hook into 'ovcd_404_slimmer_check_license' filter.
	 *
	 * @param string $license_key License key.
	 * @return array|WP_Error
	 */
	public function check_license( $license_key ) {
		/**
		 * Filter to check license validity.
		 * PRO add-on should hook here and return the result.
		 *
		 * @since 1.0.0
		 * @param array|WP_Error $result      Default error (unlicensed).
		 * @param string         $license_key The license key to check.
		 */
		return apply_filters( 'ovcd_404_slimmer_check_license', new WP_Error( 'ovcd_license_unavailable', __( 'License check is a PRO feature.', '404-slimmer' ) ), $license_key );
	}

	/**
	 * Plugin activation
	 *
	 * @return void
	 */
	public function activate() {
		// Initialize default statistics
		$default_stats = array(
			'total_blocked' => 0,
			'last_blocked' => '',
			'last_path' => '',
			'daily' => array(),
			'created' => current_time('mysql')
		);
		
		$this->save_stats($default_stats);
		
		// Set default options
		add_option('ovcd_404_slimmer_version', OVCD_404_SLIMMER_VERSION);
		add_option('ovcd_404_slimmer_use_slim_404', true);
		add_option('ovcd_404_slimmer_redirect_enabled', false);
	}

	/**
	 * Plugin deactivation
	 *
	 * @return void
	 */
	public function deactivate() {
		/**
		 * Fires on plugin deactivation.
		 * PRO add-on can hook here to clean up.
		 *
		 * @since 1.0.0
		 */
		do_action( 'ovcd_404_slimmer_deactivate' );
	}
}
