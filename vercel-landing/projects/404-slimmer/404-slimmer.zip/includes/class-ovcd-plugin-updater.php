<?php
/**
 * Plugin Update Checker – pings api.overconda.space for updates when license is valid.
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Class OVCD_Plugin_Updater
 */
class OVCD_Plugin_Updater {

	const API_BASE = 'https://api.overconda.space/api';
	const TRANSIENT_UPDATE = 'ovcd_404_slimmer_update_check';

	/**
	 * Bootstrap update hooks.
	 */
	public static function ovcd_init() {
		add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'ovcd_check_update'));
		add_filter('plugins_api', array(__CLASS__, 'ovcd_plugin_info'), 20, 3);
	}

	/**
	 * Check for updates when WordPress runs update_plugins transient.
	 *
	 * @param object $transient update_plugins transient.
	 * @return object
	 */
	public static function ovcd_check_update($transient) {
		if (empty($transient) || ! is_object($transient)) {
			return $transient;
		}

		$license_key = get_option('ovcd_404_slimmer_license_key', '');
		$status      = get_option('ovcd_404_slimmer_license_status', '');
		if (empty($license_key) || $status !== 'valid') {
			return $transient;
		}

		$current = OVCD_404_SLIMMER_VERSION;
		$slug    = 'ovcd-404-slimmer';
		$basename = OVCD_404_SLIMMER_PLUGIN_BASENAME;

		$url = add_query_arg(
			array(
				'plugin'      => $slug,
				'version'     => $current,
				'license_key' => $license_key,
				'site_url'    => OVCD_License_API::ovcd_get_site_url(),
			),
			self::API_BASE . '/update-check'
		);

		$response = wp_remote_get(esc_url_raw($url), array('timeout' => 10));

		if (is_wp_error($response)) {
			return $transient;
		}

		$code = wp_remote_retrieve_response_code($response);
		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);

		if ($code !== 200 || ! is_array($data)) {
			return $transient;
		}

		$has_update = ! empty($data['has_update']);
		$new_version = isset($data['new_version']) ? sanitize_text_field($data['new_version']) : '';
		$package = isset($data['package']) ? esc_url_raw($data['package']) : '';

		if ($has_update && $new_version && version_compare($current, $new_version, '<') && $package) {
			$item = (object) array(
				'slug'        => $slug,
				'plugin'      => $basename,
				'new_version' => $new_version,
				'url'         => 'https://overconda.space',
				'package'     => $package,
				'icons'       => array(),
				'banners'     => array(),
				'banners_rgb' => array(),
				'requires'     => isset($data['requires']) ? $data['requires'] : '',
				'tested'      => isset($data['tested']) ? $data['tested'] : '',
				'requires_php' => isset($data['requires_php']) ? $data['requires_php'] : '',
			);
			$transient->response[ $basename ] = $item;
		}

		return $transient;
	}

	/**
	 * Provide plugin info for "View details" in update screen.
	 *
	 * @param false|object|array $result Result.
	 * @param string             $action Action.
	 * @param object             $args   Args.
	 * @return false|object
	 */
	public static function ovcd_plugin_info($result, $action, $args) {
		if ($action !== 'plugin_information') {
			return $result;
		}
		$slug = 'ovcd-404-slimmer';
		if (empty($args->slug) || $args->slug !== $slug) {
			return $result;
		}

		$license_key = get_option('ovcd_404_slimmer_license_key', '');
		$status      = get_option('ovcd_404_slimmer_license_status', '');
		if (empty($license_key) || $status !== 'valid') {
			return $result;
		}

		$url = add_query_arg(
			array(
				'plugin'      => $slug,
				'version'     => OVCD_404_SLIMMER_VERSION,
				'license_key' => $license_key,
				'site_url'    => OVCD_License_API::ovcd_get_site_url(),
				'info'        => '1',
			),
			self::API_BASE . '/update-check'
		);

		$response = wp_remote_get(esc_url_raw($url), array('timeout' => 10));
		if (is_wp_error($response)) {
			return $result;
		}

		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);
		if (! is_array($data) || empty($data['info'])) {
			return $result;
		}

		$info = (object) array(
			'name'          => '404 Slimmer',
			'slug'          => $slug,
			'version'       => isset($data['new_version']) ? $data['new_version'] : OVCD_404_SLIMMER_VERSION,
			'author'        => '<a href="https://overconda.space">Overconda</a>',
			'homepage'      => 'https://overconda.space',
			'sections'      => array(
				'description' => isset($data['info']['description']) ? $data['info']['description'] : '',
				'changelog'   => isset($data['info']['changelog']) ? $data['info']['changelog'] : '',
			),
			'download_link' => isset($data['package']) ? $data['package'] : '',
		);

		return $info;
	}
}
