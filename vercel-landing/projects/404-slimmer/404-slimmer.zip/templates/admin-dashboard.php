<?php
/**
 * Admin Dashboard Template
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || exit;

// Get current statistics (real data only, no mock/demo data)
$core          = OVCD_404_Slimmer_Core::get_instance();
$stats         = $core->get_stats();
$has_real_data = ! empty( $stats['daily'] );
$load_reduction = $core->calculate_load_reduction( isset( $stats['total_blocked'] ) ? (int) $stats['total_blocked'] : 0 );
// Ensure total_blocked defaults to 0
if ( ! isset( $stats['total_blocked'] ) ) {
	$stats['total_blocked'] = 0;
}

// Single settings array for Smart Logic & Whitelist (saved by save_admin_settings)
$ovcd_settings = get_option( 'ovcd_404_slimmer_settings', array() );
$ovcd_settings = wp_parse_args(
	$ovcd_settings,
	array(
		'enable_redirect'   => 0,
		'redirect_url'      => '',
		'use_slim_template' => 1,
		'slim_style'        => 6,
		'whitelist_paths'   => '',
		'whitelist_ips'     => '',
		'enable_webhook'    => 0,
		'webhook_url'       => '',
		'custom_css'        => '',
		'custom_title'      => '',
		'custom_message'    => '',
		'custom_btn_text'   => '',
		'custom_base_style' => 6,
	)
);

// Custom 404 template fields (from options directly, fallback to settings array)
$ovcd_custom_css     = get_option( 'ovcd_404_slimmer_custom_css', $ovcd_settings['custom_css'] );
$ovcd_custom_title   = get_option( 'ovcd_404_slimmer_custom_title', $ovcd_settings['custom_title'] );
$ovcd_custom_message = get_option( 'ovcd_404_slimmer_custom_message', $ovcd_settings['custom_message'] );
$ovcd_custom_btn     = get_option( 'ovcd_404_slimmer_custom_btn_text', $ovcd_settings['custom_btn_text'] );
$ovcd_custom_base_style = (int) get_option( 'ovcd_404_slimmer_custom_base_style', isset( $ovcd_settings['custom_base_style'] ) ? $ovcd_settings['custom_base_style'] : 6 );
$ovcd_custom_base_style = max( 1, min( 6, $ovcd_custom_base_style ) );

// Determine PRO status via filter (PRO add-on hooks here)
$ovcd_is_pro = (bool) apply_filters( 'ovcd_404_slimmer_is_pro', false );

// Slim template style
$ovcd_slim_style = (int) get_option( 'ovcd_404_slimmer_slim_template_style', isset( $ovcd_settings['slim_style'] ) ? $ovcd_settings['slim_style'] : 6 );
$ovcd_slim_style = max( 1, min( 7, $ovcd_slim_style ) );
if ( ! $ovcd_is_pro ) {
	$ovcd_slim_style = 6; // FREE: White template only
}

$ovcd_settings_updated = isset( $_GET['settings-updated'] ) && sanitize_text_field( wp_unslash( $_GET['settings-updated'] ) ) === 'true';
$ovcd_stats_days       = (int) apply_filters( 'ovcd_404_slimmer_stats_days', 7 );
?>

<?php if ($ovcd_settings_updated) : ?>
	<div class="ovcd-toast ovcd-toast-success" id="ovcd-toast-settings-saved" role="status">
		<span class="ovcd-toast-icon">✓</span>
		<span class="ovcd-toast-message"><?php esc_html_e('Settings saved.', '404-slimmer'); ?></span>
	</div>
<?php endif; ?>

<div class="ovcd-branding-wrap" id="ovcd-dashboard-wrap" data-ovcd-is-pro="<?php echo esc_attr( $ovcd_is_pro ? '1' : '0' ); ?>">
	<div class="ovcd-branding-bg-layer"></div>
	<header class="ovcd-404-slimmer-header">
		<!-- วงกลมสองวง (ไม่กินพื้นที่ layout) -->
		<div class="ovcd-hero-circles-wrap" aria-hidden="true"></div>
		<div class="ovcd-grid">
			<div class="ovcd-branding-title">
				<h1>404 Slimmer</h1>
				<h2>Stop Wasting Your Server's Potential.</h2>
			</div>

		</div>
	</header>

	<div class="ovcd-404-slimmer-content">
		<?php if ( ! $has_real_data ) : ?>
			<div class="ovcd-demo-notice">
				<p><?php esc_html_e('📊 Waiting for data. Statistics will appear here once the plugin starts blocking requests.', '404-slimmer'); ?></p>
			</div>
		<?php endif; ?>

		<!-- Statistics Cards -->
		<div class="ovcd-grid">
			<div class="ovcd-card ovcd-stat-card">
				<div class="ovcd-stat-header">
					<h3 class="ovcd-stat-title"><?php esc_html_e('Traffic Saved', '404-slimmer'); ?></h3>
					<span class="ovcd-badge ovcd-badge-success"><?php echo $has_real_data ? esc_html__('Active', '404-slimmer') : esc_html__('Waiting', '404-slimmer'); ?></span>
				</div>
				<div class="ovcd-stat-value" id="ovcd-stat-requests">
					<?php echo esc_html(number_format_i18n($stats['total_blocked'])); ?>
				</div>
				<div class="ovcd-stat-label"><?php esc_html_e('Requests Blocked', '404-slimmer'); ?></div>
				<?php if (!empty($stats['last_blocked'])) : ?>
					<div class="ovcd-stat-footer">
						<small><?php esc_html_e('Last blocked:', '404-slimmer'); ?> 
							<strong><?php echo esc_html(human_time_diff(strtotime($stats['last_blocked']), current_time('timestamp'))); ?> <?php esc_html_e('ago', '404-slimmer'); ?></strong>
						</small>
					</div>
				<?php endif; ?>
			</div>

			<div class="ovcd-card ovcd-stat-card">
				<div class="ovcd-stat-header">
					<h3 class="ovcd-stat-title"><?php esc_html_e('Server Load Reduced', '404-slimmer'); ?></h3>
					<span class="ovcd-badge ovcd-badge-info"><?php esc_html_e('Estimated', '404-slimmer'); ?></span>
				</div>
				<div class="ovcd-stat-value" id="ovcd-stat-load">
					<?php echo esc_html(number_format_i18n((float) $load_reduction, 2) . '%'); ?>
				</div>
				<div class="ovcd-stat-label"><?php esc_html_e('Server Load Reduced', '404-slimmer'); ?></div>
				<div class="ovcd-stat-footer">
					<small><?php esc_html_e('Formula: Total Blocked × 0.05', '404-slimmer'); ?></small>
				</div>
			</div>
		</div>

		<!-- Daily Statistics Chart (FREE: 7 days, PRO: 30 days) -->
		<div class="ovcd-card ovcd-chart-card">
			<div class="ovcd-card-header">
				<h3 class="ovcd-card-title" id="ovcd-chart-title-wrap">
					<span id="ovcd-chart-title-text"><?php echo esc_html(sprintf(__('Daily Blocked Requests (Last %d Days)', '404-slimmer'), $ovcd_stats_days)); ?></span>
					<?php if ( ! $ovcd_is_pro ) : ?>
						<span class="ovcd-pro-lock-icon" title="<?php esc_attr_e('Pro feature', '404-slimmer'); ?>">&#128274;</span>
						<span class="ovcd-chart-unlock-wrap">
							<a href="#ovcd-license-card" class="ovcd-chart-unlock-link" id="ovcd-chart-unlock-link"><?php esc_html_e('Unlock for last 30 days', '404-slimmer'); ?></a>
						</span>
					<?php endif; ?>
				</h3>
			</div>
			<div class="ovcd-card-body">
				<div class="ovcd-chart-container">
					<canvas id="ovcd-daily-chart"></canvas>
				</div>
			</div>
		</div>

		<!-- Recent Activity -->
		<div class="ovcd-card">
			<div class="ovcd-card-header">
				<h3 class="ovcd-card-title"><?php esc_html_e('Recent Activity', '404-slimmer'); ?></h3>
			</div>
			<div class="ovcd-card-body">
				<?php if (!empty($stats['last_path'])) : ?>
					<div class="ovcd-activity-item">
						<div class="ovcd-activity-icon">🚫</div>
						<div class="ovcd-activity-content">
							<strong><?php esc_html_e('Last Blocked Path:', '404-slimmer'); ?></strong>
							<code class="ovcd-activity-code"><?php echo esc_html($stats['last_path']); ?></code>
						</div>
					</div>
				<?php else : ?>
					<p class="ovcd-empty-state"><?php esc_html_e('No blocked requests yet. The interceptor is ready and waiting.', '404-slimmer'); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<!-- Actions (Export = PRO) -->
		<div class="ovcd-card">
			<div class="ovcd-card-header">
				<h3 class="ovcd-card-title"><?php esc_html_e('Actions', '404-slimmer'); ?></h3>
			</div>
			<div class="ovcd-card-body">
				<div class="ovcd-actions">
					<button type="button" class="ovcd-btn ovcd-btn-primary" id="ovcd-refresh-stats">
						<?php esc_html_e('Refresh Statistics', '404-slimmer'); ?>
					</button>
					<button type="button" class="ovcd-btn ovcd-btn-secondary" id="ovcd-reset-stats">
						<?php esc_html_e('Reset Statistics', '404-slimmer'); ?>
					</button>
					<span class="ovcd-actions-export-wrap <?php echo ! $ovcd_is_pro ? 'ovcd-pro-feature ovcd-pro-locked' : ''; ?>">
						<button type="button" class="ovcd-btn ovcd-btn-secondary" id="ovcd-export-data" <?php echo ! $ovcd_is_pro ? 'disabled' : ''; ?>>
							<?php if ( ! $ovcd_is_pro ) : ?><span class="ovcd-pro-lock-icon" aria-hidden="true">&#128274;</span> <?php endif; ?>
							<?php esc_html_e('Export Data', '404-slimmer'); ?>
						</button>
					</span>
				</div>
			</div>
		</div>

		<!-- Smart Logic Settings -->
		<div class="ovcd-card">
			<div class="ovcd-card-header">
				<h3 class="ovcd-card-title"><?php esc_html_e('Smart Logic & Whitelist', '404-slimmer'); ?></h3>
			</div>
			<div class="ovcd-card-body">
				<form id="ovcd-settings-form" class="ovcd-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
					<input type="hidden" name="action" value="ovcd_save_404_settings">
					<?php wp_nonce_field('ovcd_save_settings', 'ovcd_settings_nonce'); ?>
					<!-- PRO: Smart Auto-Redirect -->
<div class="ovcd-form-group ovcd-pro-feature <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>">
					<label class="ovcd-label ovcd-checkbox-label">
							<input type="checkbox" name="enable_redirect" id="ovcd-redirect-enabled" value="1" <?php checked(!empty($ovcd_settings['enable_redirect'])); ?><?php echo $ovcd_is_pro ? '' : ' disabled'; ?>>
							<?php esc_html_e('Smart Auto-Redirect: redirect real users (non-bots) on 404 to URL below', '404-slimmer'); ?>
							<?php if ( ! $ovcd_is_pro ) : ?><span class="ovcd-pro-lock-icon" title="<?php esc_attr_e('Pro feature', '404-slimmer'); ?>">&#128274;</span><?php endif; ?>
						</label>
					</div>
					<div class="ovcd-form-group ovcd-pro-feature <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>">
						<label for="ovcd-redirect-url" class="ovcd-label"><?php esc_html_e('Redirect URL (leave empty for home)', '404-slimmer'); ?></label>
						<input type="url" id="ovcd-redirect-url" name="redirect_url" class="ovcd-input" placeholder="<?php echo esc_attr(home_url('/')); ?>" value="<?php echo esc_attr($ovcd_settings['redirect_url']); ?>"<?php echo $ovcd_is_pro ? '' : ' disabled'; ?>>
					</div>
					<div class="ovcd-form-group">
						<label class="ovcd-label ovcd-checkbox-label">
							<input type="checkbox" name="use_slim_template" id="ovcd-use-slim-404" value="1" <?php checked(!empty($ovcd_settings['use_slim_template'])); ?>>
							<?php esc_html_e('Use Slim 404 template (lightweight, no full theme load)', '404-slimmer'); ?>
						</label>
						<div class="ovcd-template-preview-row">
							<span class="ovcd-label"><?php esc_html_e('Style', '404-slimmer'); ?></span>
							<?php
							// Order: White first (default), then Glass, Dark, Purple, Split, Warm, Custom
							$ovcd_style_order = array( 6, 1, 2, 3, 4, 5, 7 );
							$ovcd_style_labels = array(
								1 => _x( 'Glass', '404 template style', '404-slimmer' ),
								2 => _x( 'Dark', '404 template style', '404-slimmer' ),
								3 => _x( 'Purple', '404 template style', '404-slimmer' ),
								4 => _x( 'Split', '404 template style', '404-slimmer' ),
								5 => _x( 'Warm', '404 template style', '404-slimmer' ),
								6 => _x( 'White', '404 template style', '404-slimmer' ),
								7 => _x( 'Custom', '404 template style', '404-slimmer' ),
							);
							$ovcd_pro_tooltip = esc_attr__( 'PRO Feature', '404-slimmer' );
							// จำนวน custom fields ที่ถูกเติมค่า (เพื่อรู้ว่า template ไหนเป็น base)
							$has_custom_content = ( $ovcd_custom_title !== '' || $ovcd_custom_message !== '' || $ovcd_custom_btn !== '' || $ovcd_custom_css !== '' );
							?>
							<input type="hidden" name="ovcd_custom_base_style" id="ovcd-custom-base-style" value="<?php echo (int) $ovcd_custom_base_style; ?>">
							<div class="ovcd-style-radios" id="ovcd-slim-style-radios" role="radiogroup" aria-label="<?php esc_attr_e('Slim 404 template style', '404-slimmer'); ?>">
								<?php foreach ( $ovcd_style_order as $i ) :
									$is_style_locked = ( $i !== 6 && $i !== 7 ) && ! $ovcd_is_pro; // FREE: only White (6). Custom(7) ใช้ได้เฉพาะเมื่อ Pro
									if ( $i === 7 ) {
										$is_style_locked = ! $ovcd_is_pro;
									}
									$is_pro_style = ( $i !== 6 ); // style 1-5, 7 = PRO option
									$label_class = 'ovcd-style-radio-item';
									if ( $is_style_locked ) {
										$label_class .= ' ovcd-pro-feature ovcd-pro-locked';
									}
									if ( $is_pro_style ) {
										$label_class .= ' ovcd-style-option-pro';
									}
									if ( $i === 7 ) {
										$label_class .= ' ovcd-style-custom-radio';
									}
								?>
									<label class="<?php echo esc_attr( $label_class ); ?>"<?php echo ( $is_style_locked || $is_pro_style ) ? ' title="' . esc_attr( $ovcd_pro_tooltip ) . '"' : ''; ?>>
										<input type="radio" name="slim_style" value="<?php echo (int) $i; ?>" <?php checked($ovcd_slim_style, $i); ?><?php echo $is_style_locked ? ' disabled' : ''; ?> class="ovcd-slim-style-radio" data-ovcd-pro-style="<?php echo esc_attr( $is_pro_style ? '1' : '0' ); ?>">
										<span class="ovcd-style-radio-label"><?php echo esc_html( $ovcd_style_labels[ $i ] ); ?></span>
										<?php if ( $is_pro_style ) : ?><span class="ovcd-pro-lock-icon ovcd-style-lock-icon" title="<?php echo esc_attr( $ovcd_pro_tooltip ); ?>" aria-hidden="true" style="<?php echo esc_attr( $ovcd_is_pro ? 'display:none' : '' ); ?>">&#128274;</span><?php endif; ?>
									</label>
								<?php endforeach; ?>
							</div>
							<a href="<?php echo esc_url( home_url('/__ovcd-slim-404-preview__') ); ?>" class="ovcd-btn ovcd-btn-secondary" id="ovcd-view-slim-template" target="_blank" rel="noopener noreferrer"><?php esc_html_e('View template', '404-slimmer'); ?></a>
					<div class="ovcd-custom-fields-wrap" id="ovcd-custom-fields-wrap" style="display:none;">
						<hr class="ovcd-form-divider">
						<h4 class="ovcd-form-section-title">
							<?php esc_html_e('Customize 404 Template', '404-slimmer'); ?>
						</h4>
						<p class="ovcd-form-help" style="font-size:13px; color:#888; margin-bottom:12px;">
							<?php esc_html_e('Customize text and styles for the slim 404 template. Leave blank to use defaults.', '404-slimmer'); ?>
						</p>
						<div class="ovcd-form-group">
							<div class="ovcd-form-group-restore-row">
								<label for="ovcd-custom-title" class="ovcd-label"><?php esc_html_e('404 Title (e.g., "404" or "Oops!")', '404-slimmer'); ?></label>
								<button type="button" class="ovcd-restore-default-btn" data-ovcd-restore-field="ovcd_custom_title" title="<?php esc_attr_e('Restore to default', '404-slimmer'); ?>">
									<span class="ovcd-restore-icon">↺</span> <?php esc_html_e('Restore', '404-slimmer'); ?>
								</button>
							</div>
							<input type="text" id="ovcd-custom-title" name="ovcd_custom_title" class="ovcd-input" value="<?php echo esc_attr($ovcd_custom_title); ?>" placeholder="404" disabled>
						</div>
						<div class="ovcd-form-group">
							<div class="ovcd-form-group-restore-row">
								<label for="ovcd-custom-message" class="ovcd-label"><?php esc_html_e('Message Text', '404-slimmer'); ?></label>
								<button type="button" class="ovcd-restore-default-btn" data-ovcd-restore-field="ovcd_custom_message" title="<?php esc_attr_e('Restore to default', '404-slimmer'); ?>">
									<span class="ovcd-restore-icon">↺</span> <?php esc_html_e('Restore', '404-slimmer'); ?>
								</button>
							</div>
							<input type="text" id="ovcd-custom-message" name="ovcd_custom_message" class="ovcd-input" value="<?php echo esc_attr($ovcd_custom_message); ?>" placeholder="<?php esc_attr_e('This page could not be found.', '404-slimmer'); ?>" disabled>
						</div>
						<div class="ovcd-form-group">
							<div class="ovcd-form-group-restore-row">
								<label for="ovcd-custom-btn-text" class="ovcd-label"><?php esc_html_e('Button Text', '404-slimmer'); ?></label>
								<button type="button" class="ovcd-restore-default-btn" data-ovcd-restore-field="ovcd_custom_btn_text" title="<?php esc_attr_e('Restore to default', '404-slimmer'); ?>">
									<span class="ovcd-restore-icon">↺</span> <?php esc_html_e('Restore', '404-slimmer'); ?>
								</button>
							</div>
							<input type="text" id="ovcd-custom-btn-text" name="ovcd_custom_btn_text" class="ovcd-input" value="<?php echo esc_attr($ovcd_custom_btn); ?>" placeholder="<?php esc_attr_e('Go home', '404-slimmer'); ?>" disabled>
						</div>
						<div class="ovcd-form-group">
							<div class="ovcd-form-group-restore-row">
								<label for="ovcd-custom-css" class="ovcd-label"><?php esc_html_e('Custom CSS Override', '404-slimmer'); ?></label>
								<button type="button" class="ovcd-restore-default-btn" data-ovcd-restore-field="ovcd_custom_css" title="<?php esc_attr_e('Restore to default', '404-slimmer'); ?>">
									<span class="ovcd-restore-icon">↺</span> <?php esc_html_e('Restore', '404-slimmer'); ?>
								</button>
							</div>
							<textarea id="ovcd-custom-css" name="ovcd_custom_css" class="ovcd-input ovcd-textarea ovcd-css-editor" rows="5" placeholder="body { background: #yourcolor; }&#10;.ovcd-slim-404-wrap h1 { color: red; }" disabled><?php echo esc_textarea($ovcd_custom_css); ?></textarea>
							<p class="ovcd-form-help" style="font-size:12px; color:#999; margin-top:4px;">
								<?php esc_html_e('CSS is injected into all template styles. Use classes like .ovcd-slim-404-wrap, h1, p, a to customize.', '404-slimmer'); ?>
							</p>
						</div>
					</div>
					<!-- PRO: Whitelist Paths -->
					<div class="ovcd-form-group ovcd-pro-feature <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>">
						<label for="ovcd-whitelist-paths" class="ovcd-label"><?php esc_html_e('Whitelist paths (one per line; requests matching these paths are not blocked)', '404-slimmer'); ?><?php if ( ! $ovcd_is_pro ) : ?> <span class="ovcd-pro-lock-icon" title="<?php esc_attr_e('Pro feature', '404-slimmer'); ?>">&#128274;</span><?php endif; ?></label>
						<textarea id="ovcd-whitelist-paths" name="whitelist_paths" class="ovcd-input ovcd-textarea" rows="3" placeholder="/api/&#10;/wp-admin/&#10;/custom-path" autocomplete="off"<?php echo $ovcd_is_pro ? '' : ' disabled'; ?>><?php echo esc_textarea($ovcd_settings['whitelist_paths']); ?></textarea>
					</div>
					<!-- PRO: Whitelist IPs -->
					<div class="ovcd-form-group ovcd-pro-feature <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>">
						<label for="ovcd-whitelist-ips" class="ovcd-label"><?php esc_html_e('Whitelist IPs (one per line)', '404-slimmer'); ?><?php if ( ! $ovcd_is_pro ) : ?> <span class="ovcd-pro-lock-icon" title="<?php esc_attr_e('Pro feature', '404-slimmer'); ?>">&#128274;</span><?php endif; ?></label>
						<textarea id="ovcd-whitelist-ips" name="whitelist_ips" class="ovcd-input ovcd-textarea" rows="2" placeholder="127.0.0.1&#10;192.168.1.1" autocomplete="off"<?php echo $ovcd_is_pro ? '' : ' disabled'; ?>><?php echo esc_textarea($ovcd_settings['whitelist_ips']); ?></textarea>
					</div>
					<hr class="ovcd-form-divider">
					<!-- PRO: Webhook Notifications -->
					<h4 class="ovcd-form-section-title ovcd-pro-feature <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>">
						<?php esc_html_e('Notifications (Slack / Discord)', '404-slimmer'); ?>
						<?php if ( ! $ovcd_is_pro ) : ?><span class="ovcd-pro-lock-icon" title="<?php esc_attr_e('Pro feature', '404-slimmer'); ?>">&#128274;</span><?php endif; ?>
					</h4>
					<div class="ovcd-form-group ovcd-pro-feature <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>">
						<label class="ovcd-label ovcd-checkbox-label">
							<input type="checkbox" name="enable_webhook" id="ovcd-webhook-enabled" value="1" <?php checked(!empty($ovcd_settings['enable_webhook'])); ?><?php echo $ovcd_is_pro ? '' : ' disabled'; ?>>
							<?php esc_html_e('Enable webhook notifications', '404-slimmer'); ?>
						</label>
					</div>
					<?php $webhook_enabled = !empty($ovcd_settings['enable_webhook']); ?>
					<div class="ovcd-form-group ovcd-webhook-url-wrap <?php echo esc_attr( $webhook_enabled ? 'ovcd-webhook-url-visible' : '' ); ?> <?php echo esc_attr( ! $ovcd_is_pro ? 'ovcd-pro-locked' : '' ); ?>" id="ovcd-webhook-url-wrap">
						<label for="ovcd-webhook-url" class="ovcd-label"><?php esc_html_e('Webhook URL (Slack or Discord)', '404-slimmer'); ?></label>
						<input type="url" id="ovcd-webhook-url" name="webhook_url" class="ovcd-input" placeholder="https://hooks.slack.com/..." value="<?php echo esc_attr($ovcd_settings['webhook_url']); ?>"<?php echo $ovcd_is_pro ? '' : ' disabled'; ?>>
					</div>
					<button type="submit" class="ovcd-btn ovcd-btn-primary" id="ovcd-settings-submit">
						<span class="ovcd-btn-text"><?php esc_html_e('Save Settings', '404-slimmer'); ?></span>
						<span class="ovcd-btn-spinner" aria-hidden="true" style="display:none;"></span>
					</button>
				</form>
			</div>
		</div>

		<!-- License / Upgrade Section: FREE shows upgrade prompt, PRO displays licensed info via hook -->
		<div class="ovcd-card ovcd-license-card" id="ovcd-license-card">
			<div class="ovcd-card-header">
				<h3 class="ovcd-card-title"><?php esc_html_e( 'License Information', '404-slimmer' ); ?></h3>
			</div>
			<div class="ovcd-card-body">
				<?php
				/**
				 * Fires in the license card body to display license information.
				 * PRO add-on should hook here to show licensed status.
				 *
				 * @since 1.0.0
				 * @param bool $ovcd_is_pro Whether PRO is active.
				 */
				do_action( 'ovcd_404_slimmer_license_section', $ovcd_is_pro );
				?>
				<?php if ( ! $ovcd_is_pro ) : ?>
				<div id="ovcd-license-form-wrap">
					<div class="ovcd-license-pro-message">
						<h4 class="ovcd-license-upgrade-heading">
							<span class="ovcd-license-star">⭐</span>
							<?php esc_html_e( 'Unlock PRO Features', '404-slimmer' ); ?>
						</h4>
						<p class="ovcd-license-pro-desc">
							<?php esc_html_e( 'Get access to Smart Auto-Redirect, 5 Premium 404 Templates, Whitelist, Webhook Notifications, 30-Day Charts, Data Export, and Priority Support.', '404-slimmer' ); ?>
						</p>
						<p><a href="<?php echo esc_url( OVCD_404_SLIMMER_PRO_UPGRADE_URL ); ?>" target="_blank" class="ovcd-btn ovcd-btn-primary" rel="noopener noreferrer" style="display:inline-block; text-decoration:none;"><?php esc_html_e( 'Upgrade to PRO', '404-slimmer' ); ?> →</a></p>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>


