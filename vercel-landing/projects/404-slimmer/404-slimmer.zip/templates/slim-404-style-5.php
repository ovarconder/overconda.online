<?php
/**
 * Slim 404 Template – Style 5
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr(get_bloginfo('language')); ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>404 Not Found</title>
	<?php echo $ovcd_style_css; ?>
	<?php echo $ovcd_custom_css; ?>
</head>

<body class="ovcd-slim-404 ovcd-slim-404-style-5">
	<div class="ovcd-slim-404-wrap">
		<h1><?php echo ! empty($ovcd_custom_title) ? esc_html($ovcd_custom_title) : '404'; ?></h1>
		<p><?php echo ! empty($ovcd_custom_message) ? esc_html($ovcd_custom_message) : esc_html__('This page could not be found.', '404-slimmer'); ?></p>
		<a href="<?php echo esc_url(home_url('/')); ?>"><?php echo ! empty($ovcd_custom_btn) ? esc_html($ovcd_custom_btn) : esc_html__('Go home', '404-slimmer'); ?></a>
	</div>
</body>
</html>


