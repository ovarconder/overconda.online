<?php
// === Custom Template Variables (ใช้ในทุก style template) ===
// ผู้ใช้สามารถกำหนดค่าผ่าน Dashboard → Customize 404 Template
$ovcd_custom_css     = get_option('ovcd_404_slimmer_custom_css', '');
$ovcd_custom_title   = get_option('ovcd_404_slimmer_custom_title', '');
$ovcd_custom_message = get_option('ovcd_404_slimmer_custom_message', '');
$ovcd_custom_btn     = get_option('ovcd_404_slimmer_custom_btn_text', '');

// ถ้าเป็น Style 7 (Custom) ให้ใช้ base style ของ custom template สำหรับโครงสร้าง HTML/CSS
// แต่ใช้ custom text/button/css ที่ผู้ใช้กำหนด
$custom_base_style = (int) get_option('ovcd_404_slimmer_custom_base_style', 6);
$custom_base_style = max(1, min(6, $custom_base_style));

// กำหนดค่า $style จาก option ถ้ายังไม่มี (ป้องกัน Undefined variable notice)
if (!isset($style)) {
    $style = (int) get_option('ovcd_404_slimmer_slim_template_style', 6);
    $style = max(1, min(7, $style));
}

// ถ้า style=7 (Custom) และไม่ได้อยู่ใน preview → ใช้ base_style สำหรับ template structure
// แต่ตัวแปร custom_title/custom_message/custom_btn/custom_css จะถูกส่งเข้าไปใน template
if ($style === 7) {
	// เปลี่ยน style เป็น base_style เพื่อเลือกโครงสร้าง template ที่ถูกต้อง
	$actual_template_style = $custom_base_style;
} else {
	$actual_template_style = $style;
}

// ใช้ค่าที่ผู้ใช้กำหนด ถ้าเว้นว่างไว้ใช้ค่าเริ่มต้นของแต่ละ style
// (แต่ละ style ใช้แบบ hardcoded เป็น fallback อยู่แล้ว)
// ตัวแปรเหล่านี้จะถูกใช้แทนที่ในไฟล์ template style
// ถ้าค่าว่าง ตัว template style จะใช้ default ของมันเอง
if ( $ovcd_custom_css !== '' ) {
	// Strip all HTML tags to prevent XSS — only raw CSS allowed.
	$ovcd_custom_css = "\n\t\t<!-- Custom CSS -->\n\t\t<style>\n\t\t\t" . wp_strip_all_tags( $ovcd_custom_css ) . "\n\t\t</style>";
} else {
	$ovcd_custom_css = '';
}

// Build per-style inline CSS.
// Security: The CSS below is hardcoded in the plugin source code (not user input),
// so it is safe to output directly. Custom CSS ($ovcd_custom_css) is sanitized
// via wp_strip_all_tags() above, preventing XSS.
$ovcd_style_css = '';
switch ( $actual_template_style ) {
	case 1:
		$ovcd_style_css = '
		<style>
			* { box-sizing: border-box; margin: 0; padding: 0; }
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%);
				min-height: 100vh;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #1a1a2e;
				text-align: center;
				padding: 20px;
			}
			.ovcd-slim-404-wrap {
				background: rgba(255,255,255,0.35);
				backdrop-filter: blur(10px);
				-webkit-backdrop-filter: blur(10px);
				border: 1px solid rgba(255,255,255,0.3);
				border-radius: 16px;
				padding: 2rem;
				max-width: 420px;
				box-shadow: 0 8px 32px rgba(0,0,0,0.14);
			}
			.ovcd-slim-404-wrap h1 { font-size: 4rem; margin-bottom: 0.5rem; color: #1a1a2e; }
			.ovcd-slim-404-wrap p { margin-bottom: 1.5rem; opacity: 0.9; }
			.ovcd-slim-404-wrap a {
				display: inline-block;
				padding: 10px 20px;
				background: rgba(255,255,255,0.5);
				border-radius: 8px;
				color: #1a1a2e;
				text-decoration: none;
				font-weight: 600;
				border: 1px solid rgba(255,255,255,0.4);
			}
			.ovcd-slim-404-wrap a:hover { background: rgba(255,255,255,0.7); }
		</style>';
		break;
	case 2:
		$ovcd_style_css = '
		<style>
			* { box-sizing: border-box; margin: 0; padding: 0; }
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: #0f172a;
				min-height: 100vh;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #e2e8f0;
				text-align: center;
				padding: 20px;
			}
			.ovcd-slim-404-wrap {
				border: 1px solid rgba(0, 242, 254, 0.3);
				border-radius: 12px;
				padding: 2.5rem;
				max-width: 380px;
				background: rgba(15, 23, 42, 0.9);
			}
			.ovcd-slim-404-wrap h1 { font-size: 5rem; font-weight: 200; color: #00f2fe; margin-bottom: 0.5rem; letter-spacing: 0.1em; }
			.ovcd-slim-404-wrap p { margin-bottom: 1.5rem; color: #94a3b8; font-size: 0.95rem; }
			.ovcd-slim-404-wrap a {
				display: inline-block;
				padding: 10px 24px;
				background: transparent;
				border-radius: 6px;
				color: #00f2fe;
				text-decoration: none;
				font-weight: 600;
				border: 1px solid #00f2fe;
			}
			.ovcd-slim-404-wrap a:hover { background: rgba(0, 242, 254, 0.1); }
		</style>';
		break;
	case 3:
		$ovcd_style_css = '
		<style>
			* { box-sizing: border-box; margin: 0; padding: 0; }
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: linear-gradient(160deg, #667eea 0%, #764ba2 100%);
				min-height: 100vh;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #fff;
				text-align: center;
				padding: 20px;
			}
			.ovcd-slim-404-wrap {
				background: rgba(255,255,255,0.12);
				backdrop-filter: blur(10px);
				border: 1px solid rgba(255,255,255,0.2);
				border-radius: 24px;
				padding: 3rem;
				max-width: 400px;
				box-shadow: 0 20px 60px rgba(0,0,0,0.2);
			}
			.ovcd-slim-404-wrap h1 { font-size: 5rem; font-weight: 700; margin-bottom: 0.25rem; text-shadow: 0 2px 20px rgba(0,0,0,0.2); }
			.ovcd-slim-404-wrap p { margin-bottom: 1.5rem; opacity: 0.95; font-size: 1.05rem; }
			.ovcd-slim-404-wrap a {
				display: inline-block;
				padding: 12px 28px;
				background: rgba(255,255,255,0.9);
				border-radius: 12px;
				color: #667eea;
				text-decoration: none;
				font-weight: 600;
			}
			.ovcd-slim-404-wrap a:hover { background: #fff; box-shadow: 0 4px 20px rgba(0,0,0,0.15); }
		</style>';
		break;
	case 4:
		$ovcd_style_css = '
		<style>
			* { box-sizing: border-box; margin: 0; padding: 0; }
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: linear-gradient(90deg, #0c4a6e 0%, #06b6d4 50%, #22d3ee 100%);
				min-height: 100vh;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #fff;
				padding: 20px;
			}
			.ovcd-slim-404-wrap {
				display: flex;
				align-items: center;
				gap: 2rem;
				flex-wrap: wrap;
				justify-content: center;
				background: rgba(0,0,0,0.2);
				backdrop-filter: blur(10px);
				border: 1px solid rgba(255,255,255,0.2);
				border-radius: 20px;
				padding: 2.5rem 3rem;
				max-width: 520px;
			}
			.ovcd-slim-404-wrap .ovcd-slim-404-num { font-size: 6rem; font-weight: 800; line-height: 1; color: rgba(255,255,255,0.95); }
			.ovcd-slim-404-wrap .ovcd-slim-404-body { text-align: left; }
			.ovcd-slim-404-wrap .ovcd-slim-404-body p { margin-bottom: 1rem; font-size: 1.1rem; opacity: 0.95; }
			.ovcd-slim-404-wrap a {
				display: inline-block;
				padding: 10px 20px;
				background: rgba(255,255,255,0.25);
				border-radius: 8px;
				color: #fff;
				text-decoration: none;
				font-weight: 600;
				border: 1px solid rgba(255,255,255,0.4);
			}
			.ovcd-slim-404-wrap a:hover { background: rgba(255,255,255,0.4); }
		</style>';
		break;
	case 5:
		$ovcd_style_css = '
		<style>
			* { box-sizing: border-box; margin: 0; padding: 0; }
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: linear-gradient(135deg, #fef3c7 0%, #fde68a 50%, #a7f3d0 100%);
				min-height: 100vh;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #1e293b;
				text-align: center;
				padding: 20px;
			}
			.ovcd-slim-404-wrap {
				background: rgba(255,255,255,0.7);
				backdrop-filter: blur(10px);
				border: 1px solid rgba(255,255,255,0.8);
				border-radius: 32px;
				padding: 2.5rem 3rem;
				max-width: 400px;
				box-shadow: 0 25px 50px -12px rgba(0,0,0,0.12);
			}
			.ovcd-slim-404-wrap h1 { font-size: 4.5rem; font-weight: 800; color: #0d9488; margin-bottom: 0.5rem; }
			.ovcd-slim-404-wrap p { margin-bottom: 1.5rem; color: #475569; font-size: 1rem; }
			.ovcd-slim-404-wrap a {
				display: inline-block;
				padding: 12px 24px;
				background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%);
				border-radius: 999px;
				color: #fff;
				text-decoration: none;
				font-weight: 600;
				box-shadow: 0 4px 14px rgba(13, 148, 136, 0.4);
			}
			.ovcd-slim-404-wrap a:hover { opacity: 0.95; transform: translateY(-1px); }
		</style>';
		break;
	case 6:
	default:
		$ovcd_style_css = '
		<style>
			* { box-sizing: border-box; margin: 0; padding: 0; }
			body {
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: #ffffff;
				min-height: 100vh;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #374151;
				text-align: center;
				padding: 40px 24px;
			}
			.ovcd-slim-404-wrap {
				max-width: 360px;
				padding: 3rem 0;
			}
			.ovcd-slim-404-wrap h1 {
				font-size: 3rem;
				font-weight: 300;
				color: #9ca3af;
				letter-spacing: 0.02em;
				margin-bottom: 1.5rem;
				line-height: 1.2;
			}
			.ovcd-slim-404-wrap p {
				font-size: 0.9375rem;
				color: #6b7280;
				line-height: 1.6;
				margin-bottom: 2rem;
			}
			.ovcd-slim-404-wrap a {
				display: inline-block;
				padding: 10px 0;
				color: #374151;
				text-decoration: none;
				font-size: 0.875rem;
				font-weight: 500;
				border-bottom: 1px solid #d1d5db;
			}
			.ovcd-slim-404-wrap a:hover {
				border-bottom-color: #374151;
				color: #111827;
			}
		</style>';
		break;
}

// โหลดไฟล์ตาม actual_template_style
$template_file = OVCD_404_SLIMMER_PLUGIN_DIR . 'templates/slim-404-style-' . $actual_template_style . '.php';
if (! file_exists($template_file)) {
	$template_file = OVCD_404_SLIMMER_PLUGIN_DIR . 'templates/slim-404-style-6.php';
}

include $template_file;
exit;
