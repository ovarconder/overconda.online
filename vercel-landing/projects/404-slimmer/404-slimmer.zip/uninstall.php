<?php
/**
 * Uninstall script for 404 Slimmer
 *
 * This file is executed when the plugin is uninstalled.
 * Removes all plugin options and files.
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! current_user_can( 'activate_plugins' ) ) {
	return;
}

/**
 * Fires before options are deleted, allowing PRO add-on to clean up.
 *
 * @since 1.0.0
 */
do_action( 'ovcd_404_slimmer_before_uninstall' );

$ovcd_options = array(
	'ovcd_404_slimmer_version',
	'ovcd_404_slimmer_settings',
	'ovcd_404_slimmer_redirect_enabled',
	'ovcd_404_slimmer_redirect_url',
	'ovcd_404_slimmer_use_slim_404',
	'ovcd_404_slimmer_slim_template_style',
	'ovcd_404_slimmer_whitelist_paths',
	'ovcd_404_slimmer_whitelist_ips',
	'ovcd_404_slimmer_webhook_enabled',
	'ovcd_404_slimmer_webhook_url',
	'ovcd_404_slimmer_slim_blocked_paths',
	'ovcd_404_slimmer_custom_css',
	'ovcd_404_slimmer_custom_title',
	'ovcd_404_slimmer_custom_message',
	'ovcd_404_slimmer_custom_btn_text',
	'ovcd_404_slimmer_custom_base_style',
);

foreach ( $ovcd_options as $option ) {
	delete_option( $option );
}

// Multisite: clean up network options
if ( is_multisite() ) {
	foreach ( $ovcd_options as $option ) {
		delete_network_option( null, $option );
	}
}

// Delete statistics file using wp_upload_dir() for the base directory.
$ovcd_upload_dir  = wp_upload_dir();
$ovcd_base_dir    = ! empty( $ovcd_upload_dir['basedir'] ) ? $ovcd_upload_dir['basedir'] : WP_CONTENT_DIR;
$ovcd_stats_dir   = $ovcd_base_dir . '/ovcd-404-slimmer';
$ovcd_stats_file  = $ovcd_stats_dir . '/stats.json';
$ovcd_htaccess    = $ovcd_stats_dir . '/.htaccess';
$ovcd_index       = $ovcd_stats_dir . '/index.php';

if ( file_exists( $ovcd_stats_file ) ) {
	@unlink( $ovcd_stats_file );
}
if ( file_exists( $ovcd_htaccess ) ) {
	@unlink( $ovcd_htaccess );
}
if ( file_exists( $ovcd_index ) ) {
	@unlink( $ovcd_index );
}
if ( is_dir( $ovcd_stats_dir ) ) {
	@rmdir( $ovcd_stats_dir );
}

// Remove legacy location (wp-content root)
$ovcd_legacy_stats = WP_CONTENT_DIR . '/ovcd-404-slimmer-stats.json';
if ( file_exists( $ovcd_legacy_stats ) ) {
	@unlink( $ovcd_legacy_stats );
}

// Delete transients
delete_transient( 'ovcd_404_slimmer_stats_cache' );

// Clear any scheduled events
$ovcd_cron_hooks = array( 'ovcd_404_slimmer_cleanup' );
foreach ( $ovcd_cron_hooks as $ovcd_hook ) {
	$timestamp = wp_next_scheduled( $ovcd_hook );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, $ovcd_hook );
	}
}

/**
 * Fires after options are deleted, allowing PRO add-on final cleanup.
 *
 * @since 1.0.0
 */
do_action( 'ovcd_404_slimmer_after_uninstall' );
