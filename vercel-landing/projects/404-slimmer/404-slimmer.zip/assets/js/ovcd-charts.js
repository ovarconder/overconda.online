/**
 * 404 Slimmer Charts & Statistics JavaScript
 *
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Main Chart Controller
	 */
	const OVCD404Slimmer = {
		chart: null,
		stats: null,

		/**
		 * Initialize
		 */
		init: function() {
			this.bindEvents();
			// ใช้ข้อมูลจาก PHP (mock หรือ real) สำหรับการแสดงผลครั้งแรก — ไม่เรียก AJAX ตอนโหลดเพื่อไม่ให้ทับตัวเลข mock
			if (typeof ovcd404Slimmer !== 'undefined' && ovcd404Slimmer.chartData) {
				this.stats = ovcd404Slimmer.chartData.stats;
				this.updateStatistics({
					stats: this.stats,
					load_reduction: ovcd404Slimmer.chartData.load_reduction
				});
			}
			this.initChart();
			// ไม่เรียก loadStatistics() ตอน init — ตัวเลขบนการ์ดใช้ค่าจาก PHP; กด "Refresh Statistics" ค่อยดึงจากเซิร์ฟเวอร์
		},

		/**
		 * Bind event handlers
		 */
		bindEvents: function() {
			// Refresh statistics button
			$('#ovcd-refresh-stats').on('click', () => {
				this.loadStatistics();
			});

			// Reset statistics button
			$('#ovcd-reset-stats').on('click', () => {
				if (confirm(ovcd404Slimmer.i18n.confirmReset || 'Are you sure you want to reset all statistics?')) {
					this.resetStatistics();
				}
			});

			// Export data button (PRO)
			$('#ovcd-export-data').on('click', () => {
				this.exportData();
			});



			// Settings form: native POST to admin-post.php (button state handled by inline script in dashboard)

			// อัปเดตลิงก์ "View template" ตาม radio ที่เลือกปัจจุบัน
			function updatePreviewLink() {
				const link = document.getElementById('ovcd-view-slim-template');
				if (!link) return;
				const checkedRadio = document.querySelector('.ovcd-slim-style-radio:not(:disabled):checked');
				const style = checkedRadio ? checkedRadio.value : '6';
				const base = (window.ovcd404Slimmer && window.ovcd404Slimmer.previewBaseUrl) || '';
				if (base) {
					const sep = base.indexOf('?') >= 0 ? '&' : '?';
					link.href = base + sep + 'ovcd_404_preview=' + encodeURIComponent(style) + '&nocache=' + Date.now();
				}
			}
			// อัปเดตลิงก์ทุกครั้งที่ radio เปลี่ยน
			$('#ovcd-slim-style-radios').on('change', '.ovcd-slim-style-radio', updatePreviewLink);
			// อัปเดตลิงก์เมื่อ Toggle Free/Pro เปลี่ยน (เผื่อ radio ถูก enable/disable)
			const origApplyPreview = window.ovcdApplyPreviewUI;
			if (typeof origApplyPreview === 'function') {
				window.ovcdApplyPreviewUI = function() {
					origApplyPreview.apply(this, arguments);
					updatePreviewLink();
				};
			}
			// เรียกอัปเดตครั้งแรกทันที (DOM พร้อมแล้ว, bindEvents ถูกเรียกจาก document.ready)
			updatePreviewLink();
			// คลิก View template → ใส่ nocache ก่อนเปิด browser (ให้โหลด style ล่าสุด)
			$('#ovcd-view-slim-template').on('click', function() {
				const href = $(this).attr('href');
				if (href && href.indexOf('ovcd_404_preview=') !== -1 && href.indexOf('nocache=') === -1) {
					$(this).attr('href', href + (href.indexOf('?') >= 0 ? '&' : '?') + 'nocache=' + Date.now());
				}
			});

			// Webhook URL: แสดงเมื่อติ๊ก Enable webhook, ซ่อนเมื่อยกเลิก
			$('#ovcd-webhook-enabled').on('change', function() {
				$('#ovcd-webhook-url-wrap').toggleClass('ovcd-webhook-url-visible', $(this).is(':checked'));
			});

			// PRO template: when FREE user clicks a locked style, show tooltip
			$('#ovcd-slim-style-radios').on('click', '.ovcd-style-radio-item.ovcd-pro-locked', function(e) {
				e.preventDefault();
				e.stopPropagation();
				if (window.OVCD404Slimmer && window.OVCD404Slimmer.showNotice) {
					window.OVCD404Slimmer.showNotice(ovcd404Slimmer.i18n.proFeature || 'PRO Feature', 'error');
				}
			});

			// Unlock link: smooth scroll to License section
			$(document).on('click', '#ovcd-chart-unlock-link', function(e) {
				var target = document.getElementById('ovcd-license-card');
				if (target) {
					e.preventDefault();
					target.scrollIntoView({ behavior: 'smooth', block: 'start' });
				}
			});
		},

		/**
		 * Save settings (redirect, whitelist, slim 404, webhook, custom template) via AJAX
		 */
		saveSettings: function() {
			const $form = $('#ovcd-settings-form');
			const $btn = $form.find('button[type="submit"]');
			const originalText = $btn.text();
			$btn.prop('disabled', true).text(ovcd404Slimmer.i18n.loading || 'Saving...');

			const data = {
				action: 'ovcd_404_save_settings',
				nonce: ovcd404Slimmer.nonce,
				ovcd_redirect_url: $form.find('#ovcd-redirect-url').val() || '',
				ovcd_redirect_enabled: $form.find('#ovcd-redirect-enabled').is(':checked') ? '1' : '0',
				ovcd_use_slim_404: $form.find('#ovcd-use-slim-404').is(':checked') ? '1' : '0',
				ovcd_slim_template_style: ($form.find('input[name="slim_style"]:not(:disabled):checked').val() || $form.find('input.ovcd-slim-style-radio:not(:disabled)').first().val()) || '6',
				ovcd_whitelist_paths: $form.find('#ovcd-whitelist-paths').val() || '',
				ovcd_whitelist_ips: $form.find('#ovcd-whitelist-ips').val() || '',
				ovcd_webhook_enabled: $form.find('#ovcd-webhook-enabled').is(':checked') ? '1' : '0',
				ovcd_webhook_url: $form.find('#ovcd-webhook-url').val() || '',
				// Custom 404 template fields
				ovcd_custom_css: $form.find('#ovcd-custom-css').val() || '',
				ovcd_custom_title: $form.find('#ovcd-custom-title').val() || '',
				ovcd_custom_message: $form.find('#ovcd-custom-message').val() || '',
				ovcd_custom_btn_text: $form.find('#ovcd-custom-btn-text').val() || ''
			};

			$.post(ovcd404Slimmer.ajaxUrl, data)
				.done((response) => {
					if (response.success) {
						this.showSuccess(response.data?.message || 'Settings saved.');
					} else {
						this.showError(response.data?.message || 'Failed to save.');
					}
				})
				.fail(() => this.showError('Failed to save settings.'))
				.always(() => {
					$btn.prop('disabled', false).text(originalText);
				});
		},

		/**
		 * Load statistics from server
		 */
		loadStatistics: function() {
			const $refreshBtn = $('#ovcd-refresh-stats');
			const originalText = $refreshBtn.text();
			
			$refreshBtn.prop('disabled', true).text(ovcd404Slimmer.i18n.loading || 'Loading...');

			$.ajax({
				url: ovcd404Slimmer.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ovcd_404_get_stats',
					nonce: ovcd404Slimmer.nonce
				},
				success: (response) => {
					if (response.success) {
						this.stats = response.data.stats;
						this.updateStatistics(response.data);
						this.updateChart();
					} else {
						this.showError(response.data?.message || ovcd404Slimmer.i18n.error || 'Error loading statistics');
					}
				},
				error: () => {
					this.showError(ovcd404Slimmer.i18n.error || 'Error loading statistics');
				},
				complete: () => {
					$refreshBtn.prop('disabled', false).text(originalText);
				}
			});
		},

		/**
		 * Update statistics display
		 */
		updateStatistics: function(data) {
			$('#ovcd-stat-requests').text(this.formatNumber(data.stats.total_blocked || 0));
			$('#ovcd-stat-load').text(this.formatNumber(data.load_reduction != null ? data.load_reduction : 0, 2) + '%');
		},

		/**
		 * Initialize Chart.js Line chart (Green/Cyan Glassmorphism theme)
		 */
		initChart: function() {
			const canvas = document.getElementById('ovcd-daily-chart');
			if (!canvas || typeof Chart === 'undefined') {
				return;
			}

			const chartHeight = canvas.height || 300;
			const ctx = canvas.getContext('2d');
			const lineGradient = ctx.createLinearGradient(0, 0, 0, chartHeight);
			lineGradient.addColorStop(0, '#00f2fe');
			lineGradient.addColorStop(1, '#4facfe');
			const fillGradient = ctx.createLinearGradient(0, 0, 0, chartHeight);
			fillGradient.addColorStop(0, 'rgba(0, 242, 254, 0.25)');
			fillGradient.addColorStop(0.5, 'rgba(79, 172, 254, 0.12)');
			fillGradient.addColorStop(1, 'rgba(79, 172, 254, 0.02)');

			this.chart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: [],
					datasets: [{
						label: 'Blocked',
						data: [],
						borderColor: lineGradient,
						backgroundColor: fillGradient,
						fill: true,
						tension: 0.4,
						pointRadius: 3,
						pointHoverRadius: 5,
						borderWidth: 2
					}]
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: {
						legend: { display: false }
					},
					scales: {
						x: {
							grid: { color: 'rgba(255, 255, 255, 0.1)' },
							ticks: { color: 'rgb(53, 118, 171)', maxRotation: 45 }
						},
						y: {
							beginAtZero: true,
							grid: { color: 'rgba(255, 255, 255, 0.1)' },
							ticks: { color: 'rgb(53, 118, 171)' }
						}
					}
				}
			});
			this.updateChart();
		},

		/**
		 * Update chart with daily data. Free = 7 days, Pro = 30 days (ตามโหมด preview หรือ server).
		 */
		updateChart: function() {
			if (!this.chart) {
				return;
			}
			const chartData = typeof ovcd404Slimmer !== 'undefined' && ovcd404Slimmer.chartData ? ovcd404Slimmer.chartData : {};
			const effectiveDays = (typeof window !== 'undefined' && window.ovcdPreviewDays) || chartData.stats_days || 7;
			let dailyData = chartData.daily_chart_30 || chartData.daily_chart || (this.stats && this.stats.daily) || null;
			if (!dailyData || typeof dailyData !== 'object') {
				return;
			}
			const sortedKeys = Object.keys(dailyData).sort();
			const keys = effectiveDays >= 30 ? sortedKeys : sortedKeys.slice(-effectiveDays);
			const labels = keys;
			const values = keys.map(function(date) { return dailyData[date]; });

			// X-axis: format Y-m-d from get_mock_stats() to short date
			this.chart.data.labels = labels.map(function(d) {
				try {
					var parts = d.split('-');
					if (parts.length === 3) {
						var monthDay = new Date(parts[0], parts[1] - 1, parts[2]);
						return monthDay.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
					}
					return d;
				} catch (e) {
					return d;
				}
			});
			this.chart.data.datasets[0].data = values;
			this.chart.update();
		},

		/**
		 * Reset statistics
		 */
		resetStatistics: function() {
			const $resetBtn = $('#ovcd-reset-stats');
			const originalText = $resetBtn.text();
			
			$resetBtn.prop('disabled', true).text(ovcd404Slimmer.i18n.resetting || 'Resetting...');

			$.ajax({
				url: ovcd404Slimmer.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ovcd_404_reset_stats',
					nonce: ovcd404Slimmer.nonce
				},
				success: (response) => {
					if (response.success) {
						this.showSuccess(response.data?.message || 'Statistics reset successfully');
						this.loadStatistics();
					} else {
						this.showError(response.data?.message || 'Error resetting statistics');
					}
				},
				error: () => {
					this.showError('Error resetting statistics');
				},
				complete: () => {
					$resetBtn.prop('disabled', false).text(originalText);
				}
			});
		},

		/**
		 * Verify license
		 */
		/**
		 * Deactivate license (reload to show Activate form)
		 */
		/**
		 * Export statistics data as JSON file download (PRO)
		 */
		exportData: function() {
			const $btn = $('#ovcd-export-data');
			const originalText = $btn.text();
			$btn.prop('disabled', true).text(ovcd404Slimmer.i18n.loading || 'Exporting...');

			$.ajax({
				url: ovcd404Slimmer.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ovcd_404_export_data',
					nonce: ovcd404Slimmer.nonce
				},
				success: (response) => {
					if (response.success && response.data) {
						const blob = new Blob([JSON.stringify(response.data.data, null, 2)], { type: 'application/json' });
						const url = URL.createObjectURL(blob);
						const a = document.createElement('a');
						a.href = url;
						a.download = response.data.filename || 'export.json';
						document.body.appendChild(a);
						a.click();
						document.body.removeChild(a);
						URL.revokeObjectURL(url);
						this.showSuccess('Export downloaded.');
					} else {
						this.showError(response.data?.message || 'Export failed.');
					}
				},
				error: () => {
					this.showError('Export request failed.');
				},
				complete: () => {
					$btn.prop('disabled', false).text(originalText);
				}
			});
		},

		/**
		 * Format number with thousand separators
		 */
		formatNumber: function(num, decimals = 0) {
			return Number(num).toLocaleString('en-US', {
				minimumFractionDigits: decimals,
				maximumFractionDigits: decimals
			});
		},

		/**
		 * Show success message
		 */
		showSuccess: function(message) {
			this.showNotice(message, 'success');
		},

		/**
		 * Show error message
		 */
		showError: function(message) {
			this.showNotice(message, 'error');
		},

		/**
		 * Show notice message
		 */
		showNotice: function(message, type) {
			$('.ovcd-notice').remove();

			const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
			const $p = $('<p>').css('margin', '0');

			// License error messages may contain safe HTML (<a> links) from the server
			const hasLink = typeof message === 'string' && message.indexOf('<a ') !== -1;
			if (hasLink) {
				const tmp = document.createElement('div');
				tmp.innerHTML = message;
				tmp.querySelectorAll('*').forEach(function(el) {
					if (el.tagName !== 'A') { el.replaceWith(el.textContent); return; }
					Array.from(el.attributes).forEach(function(attr) {
						if (!['href', 'target', 'rel', 'class'].includes(attr.name)) el.removeAttribute(attr.name);
					});
				});
				$p.html(tmp.innerHTML);
			} else {
				$p.text(message);
			}

			const notice = $('<div>')
				.addClass('ovcd-notice notice ' + noticeClass + ' is-dismissible')
				.css({
					position: 'fixed',
					top: '32px',
					right: '20px',
					zIndex: 100000,
					padding: '12px 20px',
					background: type === 'success' ? '#46b450' : '#dc3232',
					color: '#fff',
					borderRadius: '4px',
					boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
				})
				.append($p);

			$('body').append(notice);

			// Auto dismiss after 5 seconds
			setTimeout(() => {
				notice.fadeOut(() => notice.remove());
			}, 5000);

			// Dismiss on click
			notice.on('click', () => notice.fadeOut(() => notice.remove()));
		}
	};

	/**
	 * Initialize on document ready
	 */
	$(document).ready(function() {
		OVCD404Slimmer.init();
	});

	// Handle window resize for chart
	$(window).on('resize', function() {
		if (OVCD404Slimmer.chart && OVCD404Slimmer.stats) {
			OVCD404Slimmer.updateChart();
		}
	});

	// Expose for preview Free/Pro toggle (อัปเดตกราฟตามจำนวนวัน)
	window.OVCD404Slimmer = OVCD404Slimmer;

})(jQuery);
