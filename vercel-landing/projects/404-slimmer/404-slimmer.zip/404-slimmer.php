<?php
/**
 * Plugin Name: 404 Slimmer
 * Plugin URI: https://overconda.space
 * Description: Resource Optimization Plugin - Early 404 Interceptor to reduce server load by blocking unnecessary requests
 * Version: 1.0.0
 * Author: Overconda
 * Author URI: https://overconda.space
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: 404-slimmer
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

// Define plugin constants
define('OVCD_404_SLIMMER_VERSION', '1.0.0');
define('OVCD_404_SLIMMER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('OVCD_404_SLIMMER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OVCD_404_SLIMMER_PLUGIN_BASENAME', plugin_basename(__FILE__));
define( 'OVCD_404_SLIMMER_PRO_UPGRADE_URL', 'https://overconda.space/projects/404-slimmer' );

/**
 * License Plans Metadata
 *
 * ⚠️ IMPORTANT: Actual prices are defined in Stripe (Price IDs in checkout.controller.js).
 * The values below are for UI reference only and may become outdated.
 * Always refer to Stripe Dashboard for the authoritative prices.
 *
 * Format: {plan_slug} => { name, sites }
 *
 * personal  = Personal — 1 site
 * pro       = Pro      — 5 sites
 * agency    = Agency   — 25 sites
 */
define( 'OVCD_404_SLIMMER_PLANS', serialize( array(
	'personal' => array( 'name' => 'Personal', 'sites' => 1 ),
	'pro'      => array( 'name' => 'Pro',      'sites' => 5 ),
	'agency'   => array( 'name' => 'Agency',   'sites' => 25 ),
) ) );

/**
 * Main Plugin Class
 * 
 * @package OVCD_404_Slimmer
 * @since 1.0.0
 */
final class OVCD_404_Slimmer {

	/**
	 * Plugin instance
	 *
	 * @var OVCD_404_Slimmer
	 */
	private static $instance = null;

	/**
	 * Main plugin file path
	 *
	 * @var string
	 */
	private $plugin_file;

	/**
	 * Get plugin instance
	 *
	 * @return OVCD_404_Slimmer
	 */
	public static function get_instance() {
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		$this->plugin_file = __FILE__;
		$this->init();
	}

	/**
	 * Initialize plugin
	 *
	 * @return void
	 */
	private function init() {
		require_once OVCD_404_SLIMMER_PLUGIN_DIR . 'includes/class-ovcd-404-slimmer.php';

		// Allow PRO add-on to load its files.
		do_action( 'ovcd_404_slimmer_init' );

		// Initialize core functionality
		add_action( 'plugins_loaded', array( $this, 'load_plugin' ), 5 );

		// Form POST: Smart Logic & Whitelist saves via admin-post.php
		add_action( 'admin_post_ovcd_save_404_settings', array( $this, 'save_admin_settings' ) );

		// Register activation/deactivation hooks
		register_activation_hook( $this->plugin_file, array( $this, 'activate' ) );
		register_deactivation_hook( $this->plugin_file, array( $this, 'deactivate' ) );
	}

	/**
	 * Load core class for activation/deactivation
	 *
	 * @return void
	 */
	private function load_core_class() {
		if (!class_exists('OVCD_404_Slimmer_Core')) {
			require_once OVCD_404_SLIMMER_PLUGIN_DIR . 'includes/class-ovcd-404-slimmer.php';
		}
	}

	/**
	 * Handle Settings Saving for 404 Slimmer.
	 *
	 * @return void
	 */
	public function save_admin_settings() {
		// Check nonce for security
		if ( ! isset( $_POST['ovcd_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ovcd_settings_nonce'] ) ), 'ovcd_save_settings' ) ) {
			wp_die( esc_html__( 'Security check failed', '404-slimmer' ) );
		}

		// Check permissions
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions', '404-slimmer' ) );
		}

		/**
		 * Filter whether PRO features are available.
		 * A PRO add-on can hook here and return true.
		 *
		 * @since 1.0.0
		 * @param bool $is_pro Whether PRO features are enabled.
		 */
		$is_pro  = apply_filters( 'ovcd_404_slimmer_is_pro', false );
		$current = get_option( 'ovcd_404_slimmer_settings', array() );
		$current = is_array( $current ) ? $current : array();

		$settings = array(
			'enable_redirect'   => $is_pro && isset( $_POST['enable_redirect'] ) ? 1 : 0,
			'redirect_url'      => $is_pro && isset( $_POST['redirect_url'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_url'] ) ) : ( isset( $current['redirect_url'] ) ? $current['redirect_url'] : '' ),
			'use_slim_template' => isset( $_POST['use_slim_template'] ) ? 1 : 0,
			'slim_style'        => $is_pro && isset( $_POST['slim_style'] ) ? max( 1, min( 7, (int) $_POST['slim_style'] ) ) : 6,
			'whitelist_paths'   => $is_pro && isset( $_POST['whitelist_paths'] ) ? sanitize_textarea_field( wp_unslash( $_POST['whitelist_paths'] ) ) : '',
			'whitelist_ips'     => $is_pro && isset( $_POST['whitelist_ips'] ) ? sanitize_textarea_field( wp_unslash( $_POST['whitelist_ips'] ) ) : '',
			'enable_webhook'    => $is_pro && isset( $_POST['enable_webhook'] ) ? 1 : 0,
			'webhook_url'       => $is_pro && isset( $_POST['webhook_url'] ) ? esc_url_raw( wp_unslash( $_POST['webhook_url'] ) ) : ( isset( $current['webhook_url'] ) ? $current['webhook_url'] : '' ),
			'custom_css'        => isset( $_POST['ovcd_custom_css'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ovcd_custom_css'] ) ) : '',
			'custom_title'      => isset( $_POST['ovcd_custom_title'] ) ? sanitize_text_field( wp_unslash( $_POST['ovcd_custom_title'] ) ) : '',
			'custom_message'    => isset( $_POST['ovcd_custom_message'] ) ? sanitize_text_field( wp_unslash( $_POST['ovcd_custom_message'] ) ) : '',
			'custom_btn_text'   => isset( $_POST['ovcd_custom_btn_text'] ) ? sanitize_text_field( wp_unslash( $_POST['ovcd_custom_btn_text'] ) ) : '',
			'custom_base_style' => isset( $_POST['ovcd_custom_base_style'] ) ? max( 1, min( 6, (int) $_POST['ovcd_custom_base_style'] ) ) : 6,
		);

		if ( ! $is_pro ) {
			$settings['enable_redirect'] = 0;
			$settings['enable_webhook']  = 0;
			$settings['slim_style']      = 6;
			$settings['whitelist_paths'] = '';
			$settings['whitelist_ips']   = '';
		}

		update_option( 'ovcd_404_slimmer_settings', $settings );

		// Sync to individual options for Core class
		update_option( 'ovcd_404_slimmer_redirect_enabled', (bool) $settings['enable_redirect'] );
		update_option( 'ovcd_404_slimmer_redirect_url', $settings['redirect_url'] );
		update_option( 'ovcd_404_slimmer_use_slim_404', (bool) $settings['use_slim_template'] );
		update_option( 'ovcd_404_slimmer_slim_template_style', (int) $settings['slim_style'] );
		update_option( 'ovcd_404_slimmer_whitelist_paths', $settings['whitelist_paths'] );
		update_option( 'ovcd_404_slimmer_whitelist_ips', $settings['whitelist_ips'] );
		update_option( 'ovcd_404_slimmer_webhook_enabled', (bool) $settings['enable_webhook'] );
		update_option( 'ovcd_404_slimmer_webhook_url', $settings['webhook_url'] );
		update_option( 'ovcd_404_slimmer_custom_css', $settings['custom_css'] );
		update_option( 'ovcd_404_slimmer_custom_title', $settings['custom_title'] );
		update_option( 'ovcd_404_slimmer_custom_message', $settings['custom_message'] );
		update_option( 'ovcd_404_slimmer_custom_btn_text', $settings['custom_btn_text'] );
		update_option( 'ovcd_404_slimmer_custom_base_style', $settings['custom_base_style'] );

		/**
		 * Fires after 404 Slimmer settings have been saved.
		 * A PRO add-on can hook here to save additional settings.
		 *
		 * @since 1.0.0
		 * @param array $settings The full settings array.
		 */
		do_action( 'ovcd_404_slimmer_after_save_settings', $settings );

		// Redirect back with success message
		wp_redirect( add_query_arg( 'settings-updated', 'true', wp_get_referer() ) );
		exit;
	}

	/**
	 * Load plugin functionality
	 *
	 * @return void
	 */
	public function load_plugin() {
		// Initialize main class
		OVCD_404_Slimmer_Core::get_instance();
	}

	/**
	 * Plugin activation
	 *
	 * @return void
	 */
	public function activate() {
		// Load core class
		$this->load_core_class();
		
		// Create necessary database tables or options
		$core = OVCD_404_Slimmer_Core::get_instance();
		$core->activate();
	}

	/**
	 * Plugin deactivation
	 *
	 * @return void
	 */
	public function deactivate() {
		// Load core class
		$this->load_core_class();
		
		// Cleanup if needed
		$core = OVCD_404_Slimmer_Core::get_instance();
		$core->deactivate();
	}
}

// Initialize plugin
OVCD_404_Slimmer::get_instance();
