=== 404 Slimmer ===
Contributors: overconda
Tags: performance, optimization, 404, security, resource optimization
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Resource Optimization Plugin - Early 404 Interceptor to reduce server load by blocking unnecessary requests from bots and scanners.

== Description ==

404 Slimmer is a performance-focused WordPress plugin that intercepts 404 requests early in the WordPress loading process, before database queries and theme hooks are loaded. This significantly reduces server load and improves overall site performance.

= Free Features =

* **Early 404 Interception**: Blocks requests at the `plugins_loaded` hook, before WordPress fully loads
* **Smart Pattern Detection**: Automatically detects and blocks common bot scanning patterns (.php, .bak, .env, .sql, etc.)
* **Basic Statistics**: Tracks blocked requests (last 7 days) and calculates estimated server load reduction
* **Slim 404 Template (White)**: Lightweight 404 page that skips full theme loading
* **Beautiful Dashboard**: Glassmorphism-styled admin interface with real-time statistics

= PRO Features =

* **30-Day Statistics**: Extended statistics window (7 → 30 days)
* **Smart Auto-Redirect**: Redirect real users (non-bots) on 404 to a custom URL
* **5 Premium 404 Templates**: Glass, Dark, Purple, Split, Warm styles
* **Whitelist**: Allow specific paths and IPs to bypass blocking
* **Webhook Notifications**: Send alerts to Slack or Discord
* **Data Export**: Export statistics as JSON
* **Auto Updates**: Receive plugin updates directly in WordPress

= How It Works =

When a request comes in for a non-existent file that matches blocked patterns (like .php, .bak, .env, etc.), 404 Slimmer:

1. Detects the request early in the WordPress loading process
2. Immediately sends a 404 response
3. Stops execution before database queries and theme hooks load
4. Logs the blocked request for statistics

This saves valuable server resources, especially on sites that receive many bot scanning attempts.

= Statistics Dashboard =

The plugin includes a comprehensive dashboard showing:

* Total blocked requests
* Estimated server load reduction percentage
* Daily blocked requests chart (Free: last 7 days, PRO: last 30 days)
* Recent activity log

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/ovcd-404-slimmer` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to '404 Slimmer' in the WordPress admin menu to view the dashboard

== Frequently Asked Questions ==

= Does this affect legitimate 404 pages? =

No. The plugin only blocks requests for files that match specific patterns (like .php, .bak, .env) that are commonly used by bots and scanners. Normal 404 pages for missing content are not affected.

= Will this slow down my site? =

No, quite the opposite. By blocking unnecessary requests early, the plugin reduces server load and improves overall performance.

= What is the difference between Free and PRO? =

Free includes core 404 interception, basic 7-day statistics, and the White 404 template. PRO adds 30-day statistics, smart auto-redirect, 5 premium templates, whitelist, webhook notifications, data export, and auto-updates.

= Can I customize which file types are blocked? =

Currently, the plugin blocks common bot scanning patterns. Customization options may be available in future versions.

== Changelog ==

= 1.0.0 =
* Initial release
* Early 404 interception system
* Statistics tracking and dashboard (Free: 7 days, PRO: 30 days)
* License verification system
* Glassmorphism-styled admin interface
* 6 Slim 404 templates (1 Free + 5 PRO)
* Smart Auto-Redirect (PRO)
* Whitelist paths & IPs (PRO)
* Webhook notifications for Slack/Discord (PRO)
* Data export (PRO)

== Upgrade Notice ==

= 1.0.0 =
Initial release of 404 Slimmer.
